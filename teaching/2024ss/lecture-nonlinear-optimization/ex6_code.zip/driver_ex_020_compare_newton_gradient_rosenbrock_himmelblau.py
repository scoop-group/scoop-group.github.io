showFigs = True
# This script visualizes the behavior of various step length rules in 
# the preconditioned gradient descent method. The goal is to show the influence
# of the Armijo line search parameters, and their impact on the zig-zagging
# behavior of gradient descent for a quadratic objective.

# Decide whether figures are to be shown or saved
try:
	if showFigs:
		saveFigs = False
	else:
		saveFigs = True
except:
		saveFigs = True

import numpy as np
from globalized_newton import *
from objective_functions import *
from step_length_rules_nonlinear import *
from visualization_functions import *
from operator import itemgetter

plt.rcParams["figure.figsize"] = (10,10)

def get_configuration(configurationName):
	# Return configurations to investigate
	match configurationName:
		case 'quadratic':			
			# Set problem data
			A = np.array([[10.0, -2.0], [-2.0, 1.0]])
			b = np.array([2.0,0.0])
			c = 0

			# Set function
			fun = lambda u, derivatives: quadratic_function(u, derivatives, A, b, c)
			
			# Set bounding box that we're interested in
			xlims = (-3,3)
			ylims = (-3,3)
			
			# Compute reference solution
			reference_sol = np.array(np.linalg.solve(A,-b))
			reference_value = fun(reference_sol, [True, False, False])['function']
			
		case 'rosenbrock':
			# Set problem parameters
			a = 1
			b = 10

			# Construct function
			fun = lambda x, derivatives: rosenbrock(x, derivatives, {'a': a, 'b': b})

			# Set bounding box that we're interested in
			xlims = (-2,2)
			ylims = (-2,2)

			# Compute reference solution
			reference_sol = np.array([a,a**2])
			reference_value = fun(reference_sol, [True, False, False])['function']
			
		case 'himmelblau':
			# Set problem parameters

			# Construct function
			fun = lambda x, derivatives: himmelblau(x, derivatives)

			# Set bounding box that we're interested in
			xlims = (-6,6)
			ylims = (-6,6)

			# Compute reference solution
			reference_value = 0.0
			
		case _:
			print('<<<<<<< Unknown configuration name >>>>>>>')
			sys.exit()
					
		# Reset random number generator
	np.random.seed(0)

	# Save data for pseudo randomized initial values
	nSamples = 5
	dim = 2
	
	# Generate random initial guesses
	x0s = []
	for i in np.arange(nSamples):
		x0s.append(
			np.array(
				[
					(xlims[1]-xlims[0])*np.random.random_sample() + xlims[0],
					(ylims[1]-ylims[0])*np.random.random_sample() + ylims[0]
				]
			)
		)
				
	configuration = {
			'fun': fun,
			'xlims': xlims,
			'ylims': ylims,
			'reference_value': reference_value,
			'x0s': x0s,
			'configurationName': configurationName
		}
		
	return configuration

# Set parameters for the Armijo linesearch
armijo_parameters = {
    "initial_step_length" : 1.0,
    #"verbosity" : "verbose"
    }

# Set the parameters for the descent methods
optimization_parameters = {
	"atol_x" : 1e-10,
	"rtol_x" : 1e-10,
	"atol_f" : 1e-10,
	"rtol_f" : 1e-10,
	"atol_gradf" : 1e-10,
	"rtol_gradf" : 1e-10,
	"max_iterations" : 1e4,
	#"verbosity" : "verbose",
	"keep_history" : True,
	"eta" : 0.5,
	"rho" : 0.3,
}

# construct step length rule
armijo_step_length_rule = lambda phi, reusables: armijo_backtracking(phi, reusables, parameters = armijo_parameters)

# construct a preconditioner
P = np.eye(2) # euclidean
	
for configuration in [get_configuration(configurationName) for configurationName in ['rosenbrock','himmelblau']]:
	fun, xlims, ylims, x0s, reference_value, configurationName = itemgetter('fun', 'xlims', 'ylims', 'x0s', 'reference_value', 'configurationName')(configuration)
	
	for disable_Newton, method in zip([False, True],['glob_Newton', 'Steepest_desc']):
	
		# Make container
		outputs = []
		
		# Fix whether Newton is disabled or not
		optimization_parameters['disable_newton_steps'] = disable_Newton
		
		for x0 in x0s:
			# Solve the problem using the gradient scheme with armijo step lengths
			outputs.append(globalized_newton(fun, x0, armijo_step_length_rule, P, optimization_parameters))
			
		labels = None
		title = method + ' (' + configurationName + ')'

		# Plot the iterates
		iterFig = plot_2d_iterates_contours(lambda x: fun(x, [True, False, False])['function'], histories = list(out["history"] for out in outputs), labels = labels, title = title, xlims = xlims, ylims = ylims)

		# Plot error energy norm
		convFig = plot_f_val_diffs(list(out["history"] for out in outputs),
		[reference_value] * len(outputs),
		labels=labels,
		title = title)
		
		# Plot step sizes
		stepFig = plot_step_sizes(list(out["history"] for out in outputs),labels=labels)
		
		# Plot whether Newton direction was used
		newDirFig = plot_used_newton_direction(list(out["history"] for out in outputs),labels=labels)
		
		if saveFigs:
			for fig, name in zip([iterFig, convFig, stepFig,newDirFig], ['iterates', 'convergence', 'step-sizes','Newton-used']):
				plt.figure(fig)
				figName = '../figures/ex_020_{:s}_{:s}_{:s}.png'.format(configurationName,name,method)
				print('driver_ex_020 is saving figure: ' + figName)
				plt.savefig(figName)
				plt.close()

try:
	if showFigs:
		plt.show()
except:
	pass
