showFigs = True
# This script visualizes the set of M-gradients with corresponding half space of descent directions

# Decide whether figures are to be shown or saved
try:
	if showFigs:
		saveFigs = False
	else:
		saveFigs = True
except:
		saveFigs = True
		
import numpy as np
import matplotlib.pyplot as plt

# Wanted relative reductions of A-error
epsilons = [1e-3, 1e-9]

# Discretization of kappa
kappas = np.linspace(1,1e2,100)[1:]

# Get colors
prop_cycle = plt.rcParams['axes.prop_cycle']
colors = prop_cycle.by_key()['color']

# Bounds on steps
def SDBound (kappa,eps): return np.ceil(np.log(eps)/np.log((kappa-1)/(kappa+1)))
def CGBound (kappa,eps): return np.ceil(np.log(eps/2)/np.log((np.sqrt(kappa)-1)/(np.sqrt(kappa)+1)))

# Alternative bounds (wont be plotted unless actively uncommented)
def SDBoundAlt (kappa,eps): return np.ceil(kappa/2 * np.log(1/eps))
def CGBoundAlt (kappa,eps): return np.ceil(np.sqrt(kappa)/2 * np.log(2/eps))

fig, ax = plt.subplots(figsize = (8,8))

for eps, color in zip(epsilons,colors):
	plt.plot(kappas,SDBound(kappas,eps), color = color, marker='v', markevery=5, label = r'$\varepsilon$={:1.0e}, {:s}'.format(eps, 'SD bound'))
	#plt.plot(kappas,SDBoundAlt(kappas,eps), color = color, marker='D', markevery=5, label = r'$\varepsilon$={:1.0e}, {:s}'.format(eps, 'SD bound*'))

	plt.plot(kappas,CGBound(kappas,eps), color = color, marker='o', markevery=5, label = r'$\varepsilon$={:1.0e}, {:s}'.format(eps, 'CG bound'))
	#plt.plot(kappas,CGBoundAlt(kappas,eps), color = color, marker='s', markevery=5, label = r'$\varepsilon$={:1.0e}, {:s}'.format(eps, 'CG bound*'))

ax.set_title('Upper bounds on iterations for desired relative error reduction')
ax.set_xlabel(r'$\kappa$')
ax.set_ylabel('Worst case bound on number of iterations')
plt.legend()

if saveFigs:
	figName = '../figures/ex_009_worst_case_convergence_bounds_SDCG.png'
	print('driver_ex_009 is saving figure: ' + figName)
	plt.savefig(figName)

try:
	if showFigs:
		plt.show()
except:
	pass
