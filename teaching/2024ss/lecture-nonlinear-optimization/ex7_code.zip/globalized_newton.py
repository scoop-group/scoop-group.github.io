# This module implements the globalized newton method for solving optimization problems
# In this case, we assume the preconditioner is supplied as a matrix in order to be able to easily compute the preconditioner norm of the newton directions

import numpy as np

def globalized_newton(f, x0, step_length_rule, preconditioner, parameters = {}):
	"""
	Solve an unconstrained minimization problem using the line search globalized newton method.

	Accepts:  
		               f: the objective function to be minimized
		              x0: the initial guess (list or numpy array with ndim == 1)
		step_length_rule: a step length computation function 
		  preconditioner: a symmetric positive definite matrix (numpy array with ndim == 2)
		      parameters: optional parameters (dictionary);
		                  the following key/value pairs are evaluated:
		                                ["atol_x"]: absolute stopping tolerance for the norm of updates in x
		                                ["rtol_x"]: relative stopping tolerance for the norm of updates in x
		                                ["atol_f"]: absolute stopping tolerance for the progress in the values of f
		                                ["rtol_f"]: relative stopping tolerance for the progress in the values of f
		                            ["atol_gradf"]: absolute stopping tolerance for the norm of the gradient of f
		                            ["rtol_gradf"]: relative stopping tolerance for the norm of the gradient of f
		                                            Here 'norm' refers to the preconditioner-induced norm.
		                        ["max_iterations"]: maximum number of iterations
		                                   ["eta"]: globalization parameter
		                                   ["rho"]: globalization parameter
		                                     ["p"]: globalization parameter
		                             ["verbosity"]: "verbose" or "quiet"
		                          ["keep_history"]: whether or not to store the iteration history (True or False) 
		                  ["disable_newton_steps"]: whether or not the method should revert to a preconditioned gradient method (True or False)
    
	Returns: 
		       result: a dictionary containing 
		     solution: final iterate
		     function: the final iterate's objective value 
		     gradient: the final iterate's objective gradient value
		norm_gradient: preconditioner-induced norm of final objective gradient 
		         iter: number of iterations performed
		     exitflag: flag encoding why the algorithm terminated
		               0: stopping tolerance described by atol_x, rtol_x, atol_f, rtol_f reached
		               1: stopping tolerance described by atol_gradf and rtol_gradf reached
		               2: maximum number of iterations reached
		      history: a dictionary for the history of the run containing
		                            iterates: the iterates x
		                    objective_values: the values of the objective function
		                      gradient_norms: the norms of the objective function gradient 
		                       steps_lengths: the step lengths chosen by the step length rule
		               used_newton_direction: the information whether or not the newton direction was used
	"""
	# Define computation of the squared preconditioner norm
	def norm2(d): return d.dot(preconditioner.dot(d))
  
	# Define an output function that will be used to print information on the state of the iteration
	def print_header():
		print('--------------------------------------------------------------------')
		print(' ITER          OBJ    NORM_GRAD    NORM_CORR     OBJ_CHNG           ')
		print('--------------------------------------------------------------------')

	# Define exitflags that will be printed when the algorithm terminates
	exitflag_messages = [
		'Relative and absolute tolerances on the norm of the update and the descent of the objective are satisfied.',
		'Relative and absolute tolerances on the norm of the gradient are satisfied.',
		'Maximum number of optimization steps is reached.',
		]

	# Get the algorithmic parameters, using defaults if missing
	atol_x = parameters.get("atol_x", 1e-6)
	rtol_x = parameters.get("rtol_x", 1e-6)
	atol_f = parameters.get("atol_f", 1e-6)
	rtol_f = parameters.get("rtol_f", rtol_x**2)
	atol_gradf = parameters.get("atol_gradf", 1e-6)
	rtol_gradf = parameters.get("rtol_gradf", 1e-6)
	max_iterations = parameters.get("max_iterations", 1e3)
	eta = parameters.get("eta", 1e-6)
	rho = parameters.get("rho", 1e-6)
	p = parameters.get("p", 0.1)
	verbosity = parameters.get("verbosity", "quiet")
	keep_history = parameters.get("keep_history", False)
	disable_newton_steps = parameters.get("disable_newton_steps", False)

	# Initialize the iterates, counters etc.
	x = x0
	iter = 0
	exitflag = None
	used_newton_direction = None
  
	# Initialize dummy values pertaining to the previous iterate
	x_old = np.full(x0.shape, np.inf)
	function_value_old = np.inf
  
	# Prepare a dictionary to store the history
	if keep_history:
		history = {
			"iterates" : [],
			"objective_values" : [],
			"gradient_norms" : [],
			"step_lengths" : [],
			"used_newton_direction" : []
			}

	# Perform newton/gradient descent steps until one of the termination criteria is met
	while exitflag is None:
		# Record the current iterate
		if keep_history: history["iterates"].append(x)

		# Dump some output
		if verbosity == 'verbose':
			if (iter%10 == 0): print_header()
			print(' %4d  ' % (iter), end = '')

		# Stop when the maximum number of iterations has been reached
		if iter >= max_iterations:
			exitflag = 2
			break

		# Compute the function value and derivative at current iterate
		values = f(x, derivatives = [True, True, True])
		function_value = values["function"]
		derivative = values["derivative"]
		hessian = values["Hessian"]

		# Record the current value of the objective
		if keep_history: history["objective_values"].append(function_value)

		# Dump some output
		if verbosity == 'verbose': print('%11.4e  ' % (function_value), end = '')

		# Compute the preconditioned gradient and the square of its (preconditioner-induced) norm
		gradient = np.linalg.solve(preconditioner, derivative)
		norm2_gradient = derivative.dot(gradient)
		
		# Check the computed norm square for positivity
		if norm2_gradient < 0:
			raise ValueError('Your preconditioner appears not to be positive definite.')
		else:
			norm_gradient = np.sqrt(norm2_gradient)

		# Record the current norm of the gradient
		if keep_history: history["gradient_norms"].append(norm_gradient)

		# Remember the norm of the initial gradient
		if (iter == 0): initial_norm_gradient = norm_gradient

		# Dump some output
		if verbosity == 'verbose': print('%11.4e  ' % (norm_gradient), end = '')

		# Stop when the stopping tolerance on the norm of the gradient has been reached
		if norm_gradient <= atol_gradf + rtol_gradf * initial_norm_gradient:
			exitflag = 1
			break

		# Evaluate the norm of the update step
		norm_delta_x = np.sqrt(norm2(x - x_old))

		# Evaluate the change in the objective function values
		delta_f = function_value_old - function_value

		# Evaluate the reference values for relative tolerances
		abs_function_value_old = np.abs(function_value_old)
		norm_x_old = np.sqrt(norm2(x_old))

		# Dump some output
		if verbosity == 'verbose': print('%11.4e  %11.4e' % (norm_delta_x, -delta_f))

		# Stop when the stopping tolerance on the change in the objective and the
		# norm of the update step have been reached
		if (delta_f < atol_f + rtol_f * abs_function_value_old) and\
		   (norm_delta_x < atol_x + rtol_x * norm_x_old):
			exitflag = 0
			break

		# Set the update direction
		try:
			if disable_newton_steps: raise BaseException("Newton directions are disabled")

			# Compute Newton direction and its (preconditioner induced) norm
			d = np.linalg.solve(hessian, -derivative)
			norm2_d = norm2(d)

			# Check Newton direction for quality
			if -derivative.dot(d) <= min(eta, rho * norm_gradient ** p) * np.sqrt(norm2_d) * norm_gradient:
				raise ValueError(f"Iteration {iter} (globalized Newton): Newton direction is of poor quality")
			used_newton_direction = True
		except ValueError as e:
			print(e)
			# Fall back to gradient direction if Newton direction could not be computed or is of poor quality
			used_newton_direction = False
			d = -gradient
		except BaseException as e:
			print(e)
			# Fall back to gradient direction if Newton direction could not be computed or is of poor quality
			used_newton_direction = False
			d = -gradient
		
		# Prepare the line search function, using the function values of the
		# objective and its derivatives and the chain rule
		def phi(t, derivatives):
			values = f(x + t * d, derivatives)
			if derivatives[1]:
				values["derivative"] = values["derivative"].dot(d)
			if derivatives[2]:
				values["Hessian"] = d.dot(values["Hessian"].dot(d))
			return values

		# Prepare some data to pass down to the step length computation rule
		reusables = {
			"phi0" : function_value,
		}
		if not used_newton_direction: reusables["dphi0"] = -norm2_gradient

		# Evaluate the step length t using the step length rule
		t, t_exitflag = step_length_rule(phi, reusables)

		# Check whether of not the step length was computed succesfully
		if t_exitflag: raise AssertionError('Step length was not computed succesfully.')

		# Record the chosen step length 
		if keep_history: history["step_lengths"].append(t)

		# Save the current iterate and associated function value for the next iteration
		x_old = x
		function_value_old = function_value
		
		# Update the iterate and increase the counter
		x = x + t * d
		iter = iter + 1
		
		# Remember whether or not the newton direction was used as update direction
		if keep_history: history["used_newton_direction"].append(used_newton_direction)

	# Dump some output
	if verbosity == 'verbose':
		print('\n\nThe globalized newton is exiting with flag %d.\n' %(exitflag) + str(exitflag_messages[exitflag])+'\n' )
	
	# Create and populate the result to be returned
	result = {
		"solution" : x,
		"function" : function_value,
		"gradient" : gradient,
		"norm_gradient" : norm_gradient,
		"iter" : iter,
		"exitflag" : exitflag
	}
	
	# Assign the history to the result if required
	if keep_history:
		result["history"] = history
	
	return result
