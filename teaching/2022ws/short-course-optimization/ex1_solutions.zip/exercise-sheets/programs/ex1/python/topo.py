import numpy as np

# Define landscape topography by function values
def topo(X,Y):
	X = np.array(X)
	Y = np.array(Y)

	f = lambda x: 2/(1+x**2)
	Z = np.zeros(X.shape)

	for i,(x,y) in enumerate(zip(X,Y)):
		a1 = -f(3 - 0.7*x**2 - 5*y)
		a2 = f(5*(x - 0.7)**2 + 20*(y - 0.1)**2)
		a3 = f(4 + 2*x**2 - 4*y)
		a4 = 0.5*np.sin(4*(x - y**2))*np.sin(3*(y + x**2))
		a5 = 0.6*f(50*((x + 1)**2+(y + 0.8)**2 - 0.25)**2)
		Z[i] = (a1+a2+a3+a4+a5-1/6)/8
	return Z
