function plot_chain(problem,x,y,lambda,show_forces,window)
% This routine displays the chain, given the node positions x and y.
% It optionally also displays the forces acting at the supports,
% within the rope segments, as well as through contact with the obstacle.

% Get some variables
N = length(x);
figure()

% Get support forces (pad them with zeros where the support 
% does not act in both directions)
ix = find(~isnan(problem.supports(:,2:3)'));
tmp = lambda.eqlin;
lambda.eqlin = zeros(2*size(problem.supports,1),1);
lambda.eqlin(ix) = tmp;
support_forces = reshape(lambda.eqlin,2,[]);

% Get rope and obstacle forces
if (isempty(problem.obstacle))
	rope_forces = lambda.ineqnonlin;
else
	obstacle_forces = lambda.ineqnonlin(1:N);
	rope_forces = lambda.ineqnonlin(N+1:end);
end

% Define colors for low and high rope forces
color_low = [0.7 0.7 0.7];
color_high = [1.0 0.0 0.0];

% Prepare the figure
hold on

% Display the chain once in order to get a good scaling of the window
plot(x,y,'-','LineWidth',2);

% Set figure axes
if (nargin == 6)
	axis(window)
else
	axis equal
end

% Display the obstacle (if any)
if (~isempty(problem.obstacle))
	% Get current axis limits to create a meshgrid
	XLim = get(gca,'XLim'); YLim = get(gca,'YLim');
	[X,Y] = meshgrid(linspace(XLim(1),XLim(2),51),linspace(YLim(1),YLim(2),41));
	Z = problem.obstacle(problem,X,Y);
	% Produce a filled contour plot, provided that the zero contour 
	% is at all visible in the domain
	if ((min(Z(:)) < 0) & max(Z(:)) > 0)
		levels = linspace(0,max(max(Z)),2);
		if (levels(2) < levels(1))
			levels = fliplr(levels);
		end
		color = [0.8 0.8 1];
		[c,h] = contourf(X,Y,Z,levels,'Color',color);
		hold on
		patches = findobj(h,'-property','FaceColor')';
		for ph = patches
			set(ph,'FaceColor',color);
		end
	else
		fprintf('Note: The boundary of the obstacle is not visible in the domain shown.\n');
	end
end

% Display the rope links last (so they appear on top of everything painted so far)
% If desired, show the force in each rope segment
if (strcmpi(show_forces,'on'))
	max_rope_force = 0.5;
	for i=1:N-1
		color = color_low + min(rope_forces(i),max_rope_force) / max_rope_force * (color_high - color_low);
		plot([x(i),x(i+1)],[y(i),y(i+1)],'Color',color,'LineWidth',3);
	end
else
	plot(x,y,'Color',color_low,'LineWidth',3);
end

% Display the nodes with sizes corresponding to their weights
w_min = min(problem.weights); w_max = max(problem.weights);
if (w_max == w_min) w_max = w_min + 1; end
s_min = 6; s_max = 10;
for i=1:N
	msize = s_min+(s_max-s_min)/(w_max-w_min)*(problem.weights(i)-w_min);
	plot(x(i),y(i),'ko','MarkerSize',msize,'MarkerFaceColor','k');
	hold on
end

% Display the supports
for i=1:size(problem.supports,1)
	j = problem.supports(i,1);
	if (sum(~isnan(problem.supports(i,2:3))) == 2)
		plot(x(j),y(j),'ko','MarkerSize',s_max + 2);
		hold on
	elseif (~isnan(problem.supports(i,2)))
		plot(x(j),y(j),'k>','MarkerSize',s_max + 6);
	elseif (~isnan(problem.supports(i,3)))
		plot(x(j),y(j),'k^','MarkerSize',s_max + 6);
	end
end

% If desired, show the forces acting in the supported nodes
if (strcmpi(show_forces,'on'))
	for i=1:size(problem.supports,1)
		vector = support_forces(:,i);
		% Make sure the vector points upwards
		% (For some reason, linear equality constraints are sometimes flipped.)
		vector = vector * sign(vector(2));
		quiver(x(problem.supports(i,1)),y(problem.supports(i,1)),vector(1),vector(2),'Color','k','LineWidth',2);
	end
end

% If desired, show the forces acting on the obstacle (if any) in normal direction.
% Note that the Lagrange multipliers need not be scaled although the obstacle
% does not necessarily satisfy | \nabla \phi | = 1. The reason is that 
% lambda \nabla \phi represents the force whatever the scaling of \phi is.
if (strcmpi(show_forces,'on')) && ~isempty(problem.obstacle)
	ix = find(lambda.ineqnonlin(1:N));
	for i=1:length(ix)
		[~,grad] = problem.obstacle(problem,x(ix(i)),y(ix(i)));
		vector = lambda.ineqnonlin(ix(i)) * grad;
		quiver(x(ix(i)),y(ix(i)),vector(1),vector(2),'Color','k','LineWidth',2);
	end
end

% Beautify the figure
if (nargin == 6)
	axis(window)
else
	axis equal
end

% Get current axis settings
ax = axis;

% Calculate width and height
lx = ax(2) - ax(1);
ly = ax(4) - ax(3);

% Set new axes a bit wider
axis(ax + 0.05 * [-lx lx -ly ly]);



