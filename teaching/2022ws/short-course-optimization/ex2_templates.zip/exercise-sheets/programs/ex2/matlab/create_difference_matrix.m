function A = create_difference_matrix(n1,n2)
%This function creates a sparse matrix of horizontal and vertical differences between neighboring pixels for an image of size n1 (vertical) times n2 (horizontal).

single_index  = @(i1, i2, n1) i1 + n1* i2 + 1;

% Initialize the matrices holding the non-zero entries (rows, columns, values).
rows = [];
cols = [];
vals = [];

% Create the entries pertaining to the tails of horizontal differences.
how_many = n1 * (n2-1);
for i1 = 0:n1-1
    for i2 = 0:n2-2
        rows = [rows, single_index(i1, i2, n1)];
    end
end
cols = [cols, 1:how_many];
vals = [vals, -ones(1,how_many)];

% Create the entries pertaining to the heads of horizontal differences.
for i1 = 0:n1-1
    for i2 = 0:n2-2
        rows = [rows, single_index(i1, i2+1, n1)];
    end
end
cols = [cols, 1:how_many];
vals = [vals, ones(1,how_many)];

% Create the entries pertaining to the tails of vertical differences.
how_many = n2 * (n1-1);
ncols = max(cols)-1;
for i2 = 0:n2-1
    for i1 = 0:n1-2
        rows = [rows, single_index(i1, i2, n1)];
    end
end
cols = [cols, ncols+2 : ncols+1+how_many];
vals = [vals, -ones(1,how_many)];

% Create the entries pertaining to the heads of vertical differences.
for i2 = 0:n2-1
    for i1 = 0:n1-2
        rows = [rows, single_index(i1+1, i2, n1)];
    end
end
cols = [cols, ncols+2 : ncols+1+how_many];
vals = [vals, ones(1,how_many)];

% Create the sparse matrix A transpose, but return A.
A = sparse(rows, cols, vals)';
end