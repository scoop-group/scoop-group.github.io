function problem = chain_configurations(configuration_name,N)
% Function that returns the requested problem configuration

switch configuration_name
    case 'data_chain_free'
        problem.weights = ones(N,1) / N;
        
        problem.supports = [ ...
        1  0.0  0.0; ...
        N  1.0  0.0 ];
        
        problem.link_length = 1.5 / (N-1);
        
        problem.obstacle = [];
    case 'data_chain_triple'
        problem.weights = ones(N,1) / N;
        
        N2 = round(N/2);
        problem.supports = [ ...
        1  0.0  0.0; ...
        N2 0.45 -0.2; ...
        N  1.0  0.0 ];
        
        problem.link_length = 2 / (N-1);
        
        problem.obstacle = [];
    case 'data_chain_flat'
        problem.weights = ones(N,1) / N;

        problem.supports = [ ...
        1  0.0  0.0; ...
        N  1.0  0.0 ];
        
        problem.link_length = 1.2 / (N-1);
        
        problem.obstacle = @obstacle_chain_flat;
    case 'data_chain_cubic'
        problem.weights = ones(N,1) / N;
        
        problem.supports = [ ...
        1  0.0  0.0; ...
        N  1.0  0.0 ];
        
        problem.link_length = 2 / (N-1);
        
        problem.obstacle = @obstacle_chain_cubic;
    case 'data_chain_circle'
        problem.weights = ones(N,1) / N;

        problem.supports = [ ...
        1  0.0  0.0; ...
        N  1.0  0.0 ];
        
        problem.link_length = 2 / (N-1);
        
        problem.obstacle = @obstacle_chain_circle;
    otherwise
        disp('<<<<<<< Unknown configuration name >>>>>>>')
    end
end

function [phi,grad_phi] = obstacle_chain_flat(problem,x,y)
    % This function realizes a flat obstacle phi
    % such that phi <= 0 is feasible.
    
    % Evaluate the obstacle function and its gradient
    phi = -0.1 - y;
    grad_phi = [zeros(size(y)); -ones(size(y))];

end

function [phi,grad_phi] = obstacle_chain_cubic(problem,x,y)
    % This function realizes a cubic non-convex obstacle phi
    % such that phi <= 0 is feasible.
    
    % Set parameters of cubic polynomial
    a3 = -2; a2 = 1; a1 = +0.3; a0 = -0.5;
    
    % Evaluate the obstacle function and its gradient
    phi = a3 * x.^3 + a2 * x.^2 + a1 * x.^1 + a0 * x.^0 - y;
    grad_phi = [3 * a3 * x.^2 + 2 * a2 * x.^1 + 1 * a1 * x.^0; -ones(size(y))];
end

function [phi,grad_phi] = obstacle_chain_circle(problem,x,y)
    % This function realizes a circular convex obstacle phi
    % such that phi <= 0 is feasible.
    
    % Set circle parameters
    xmid = 0.5;
    ymid = 0.2;
    r = 0.7;
    
    % Evaluate the obstacle function and its gradient
    phi = (x-xmid).^2 + (y-ymid).^2 - r^2;
    grad_phi = [2*(x-xmid); 2*(y-ymid)];
end