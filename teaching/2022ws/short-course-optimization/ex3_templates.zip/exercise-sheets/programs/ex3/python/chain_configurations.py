import numpy as np
import sys

# Return a dictionary with configuration data
def chain_configuration(configuration_name = 'data_chain_free', N = 20):

    match configuration_name:
        case 'data_chain_free':
            weights = 1/N * np.ones(N)
            length = 1.5
            supports = np.array([ [0, 0.0, 0.0], [N-1, 1.0, 0.0]])

        case 'data_chain_triple':
            weights = 1/N * np.ones(N)
            length = 2
            supports = np.array([ [0, 0.0, 0.0],
                                  [np.round(N/2), 0.45, -0.2],
                                  [N-1, 1.0, 0.0]])

        case 'data_chain_flat':
            weights = 1/N * np.ones(N)
            length = 1.2
            supports = np.array([ [0, 0.0, 0.0], [N-1, 1.0, 0.0]])
            fun_obs = lambda x,y: -0.1 - y
            dfun_obs = lambda x,y: np.hstack((np.zeros((N,N)), - np.eye(N)))

        case 'data_chain_cubic':
            weights = 1/N * np.ones(N)
            length = 2
            supports = np.array([ [0, 0.0, 0.0], [N-1, 1.0, 0.0]])
            a3 = -2
            a2 = 1
            a1 = 0.3
            a0 = -0.5
            fun_obs = lambda x,y: a3 * x**3 + a2 * x**2 + a1 * x**1 + a0 * x**0 - y
            dfun_obs = lambda x,y: np.hstack((np.diag(3*a3 * x**2 + 2*a2 * x + a1), - np.eye(N)))

        case 'data_chain_circle':
            weights = 1/N * np.ones(N)
            length = 2
            supports = np.array([ [0, 0.0, 0.0], [N-1, 1.0, 0.0]])
            cx = 0.5
            cy = 0.2
            r = 0.7
            fun_obs = lambda x,y: (x-cx)**2 + (y-cy)**2 - r**2
            dfun_obs = lambda x,y: np.hstack((2*np.diag(x-cx), 2*np.diag(y-cy)))

        case _:
            print('<<<<<<< Unknown configuration name >>>>>>>')
            sys.exit()

    problem = {
            'Name': configuration_name,
            'N' : N,
            'link_length': length/(N-1),
            'weights': weights,
            'supports': supports
        }

    try:
        problem['fun_obs']  = fun_obs
        problem['dfun_obs'] = dfun_obs
    except:
        pass

    return problem
