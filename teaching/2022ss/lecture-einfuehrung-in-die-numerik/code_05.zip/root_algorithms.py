import numpy as np

def compute_roots(p, q, mode = 'stable', fps = float):
	"""
	Computes roots of the quadratic polynomial x^2-2px-q given as
		x0 = p-sqrt(p^2+q) = -q/x_1 (vieta)
		x1 = p+sqrt(p^2+q) = -q/x_0 (vieta)
	in specified floating point system (fps) if they are real and aborts otherwise.
	
	If mode is 'naive', the first formula is used for both roots.
	If mode is 'stable', the first formula is used for the root that is not prone to cancellation errors
	and the second formula (vieta) is used for the remaining root.
	Defaults mode to 'stable'.
		
	Accepts:
		       p   : part of coefficient in linear term
		       q   : part of coefficient in constant term
		       mode: computational mode for roots
		             naive: Compute both roots naively
		             stable: Compute the cancellation prone root using vieta (default)
		       fps : any function converting a given number into a number in the floating point system (defaults to built in double precision float)
	Returns: 
		       x0: first root (lower or equal value compared to x1)
		       x1: second root (greater or equal value compared to x1)
	"""
	# Make sure both arguments are real scalars
	assert np.all(np.isreal([p,q])), "Did not receive two real scalars."
	
	# Convert input numbers if needed
	p,q = fps(p),fps(q)

	# Compute the sum of parameters that enter root function
	sum_under_root = fps(fps(p)*fps(p) + fps(q))
	
	# Make sure there is at least one real root
	assert sum_under_root >= 0, "Function does not have a real root."
	# compute square root term
	root_term = fps(np.sqrt(sum_under_root,dtype=type(p)))
	if mode == 'naive':
		x0 = fps(p - root_term)
		x1 = fps(p + root_term)
	else: 
		# stable computation
		# Case 1, p is negative, compute x0 first (add two negative numbers)
		if p<0:
			x0 = fps(p - root_term)
			x1 = fps(-q/x0)
		# Case 2, p is positive, compute x1 first (add two positive numbers)
		else:
			x1 = fps(p + root_term)
			x0 = fps(-q/x1)
	
	return x0, x1
