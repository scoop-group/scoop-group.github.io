# Script that shows the finite termination of the harmonic series in finite precision arithmetic

import sys
import os
import numpy as np
import root_algorithms as ra

# Set output filestream name
output_filename = os.path.splitext(os.path.basename(__file__))[0] + '_output.txt'

# Open output filestream
with open(output_filename, 'w') as filestream:
	# Set the modes we will compute in 
	modes = ['naive', 'stable']

	# Set the floating point systems we will compute in
	floating_point_systems = [np.float32,np.float64]
	reference_floating_point_system = np.float128
	floating_point_systems.append(reference_floating_point_system)

	# Set the p and the q we will use as strings to be initialized in fps representation later
	p = ['1', '1e2', '1e4','-1', '-1e2', '-1e4']
	q = ['1',   '1',   '1', '1',    '1',    '1']

	# Start computing
	for p, q in zip(p, q):
		# Dump output
		print(">> Computing roots for p = {} and q = {} in floating point systems: ".format(p, q, floating_point_systems[0:-2]) + " ".join(['{}'] * len(floating_point_systems)).format(*list(fps.__name__ for fps in floating_point_systems)), file=filestream)
		results = []
		for fps in floating_point_systems:
			for mode in modes:
				# Initialize p and q in fps representation (this potentially gives rounding error in fps depending on p / q)
				p, q = fps(p), fps(q)
				
				# Compute roots
				x0, x1 = ra.compute_roots(p, q, mode, fps)
				result = {
				'mode': mode,
				'fps': fps,
				'roots': [x0,x1],
				'pq': [p,q]
				}
				results.append(result)
				
				# Dump output
				print('{:>6} roots in {:>8} are: {: 1.19e} and {: 1.19e}'.format(mode, fps.__name__, x0, x1), file = filestream)

		# Find roots for stable mode and high precision
		reference_roots = next(result['roots'] for result in results if (result["mode"] == "stable" and result["fps"] == floating_point_systems[-1]))
		reference_roots = np.array(reference_roots)
		
		# Print relative errors for roots in all other precision computation
		low_precision_results = (result for result in results if result["fps"] != floating_point_systems[-1])
		for result in low_precision_results:
			# Get roots
			roots = result['roots']
			roots = np.array(roots)

			# Compute relative error
			rel_error = np.abs(roots-reference_roots)/np.abs(reference_roots)
			bad_root_index = np.argmax(rel_error)
			
			# Dump output
			#print(">> Relative {:>8}-errors in {:>6} mode (to stable {:>8}-solutions):".format(result['fps'].__name__, result['mode'], floating_point_systems[-1].__name__) + ' '.join(['{: 1.5e}', '{: 1.5e}']).format(*rel_error), file=filestream)
			print(">> Relative {:>8}-errors in {:>6} mode:".format(result['fps'].__name__, result['mode']) + ' '.join(['{: 1.5e}', '{: 1.5e}']).format(*rel_error), file=filestream)
		print("",file=filestream)
