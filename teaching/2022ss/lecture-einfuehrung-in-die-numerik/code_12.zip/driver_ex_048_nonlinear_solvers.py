'''
Script that compares behavior of bisection, fixed point iteration and local Newton for finding roots of functions for several examples
'''
import sys
import os
import numpy as np
import matplotlib.pyplot as plt
from operator import itemgetter
import nonlinear_solvers as nls

np.seterr(all='raise')

# Set output filestream name
output_filename = os.path.splitext(os.path.basename(__file__))[0] + '_output.txt'

# Set examples to run computations on
examples = [
	{
		'name': 'Square_root_problem',
		'function': lambda x: x**2 - 0.5,
		'derivative': lambda x: 2*x,
		'roots': [-1/2**0.5, 1/2**0.5],
		'initial_guesses': [0.5, -0.5, 0, 2],
		'initial_intervals': [(x-1, x+1) for x in [0.5, -0.5, 0, 2]],
	},
	{
		'name': 'Logarithm_problem',
		'function': lambda x: np.exp(x) - 2,
		'derivative': lambda x: np.exp(x),
		'roots': [np.log(2)],
		'initial_guesses': [0, np.log(2) + 1e-8, 10],
		'initial_intervals': [(x-1, x+1) for x in [0, np.log(2) + 1e-8, 10]],
	},
	{
		'name': 'Rational_problem',
		'function': lambda x: 2*x/(1 + x**2),
		'derivative': lambda x: 2*(1-x**2)/(1+2*x**2+x**4),
		'roots': [0],
		'initial_guesses': [0.5, 1, 1 - 1e-8],
		'initial_intervals': [(x-1, x+1) for x in [0.5, 1, 1 - 1e-8]],
	}
]
	
# Set flags on which solvers to use
run_bisection, run_fixed_point, run_newton = 1, 1, 1
	
with open(output_filename, 'w') as filestream:
	# Set the solver options
	bisection_options = {
			'aTol': 1e-5,
			'rTol': 1e-4,
			'verbosity': 'verbose',
			'filestream': filestream,
			'keep_history': True,
	}
	fixed_point_options = {
			'update_aTol': 1e-5,
			'update_rTol': 1e-4,
			'residual_aTol': 1e-5,
			'max_iter': 100,
			'verbosity': 'verbose',
			'filestream': filestream,
			'keep_history': True
	}
	newton_options = {
			'update_aTol': 1e-5,
			'update_rTol': 1e-4,
			'residual_aTol': 1e-5,
			'max_iter': 100,
			'verbosity': 'verbose',
			'filestream': filestream,
			'keep_history': True
	}

	print('>>>>>>>>>>>>>>>>>>>>>> Comparing root finding methods <<<<<<<<<<<<<<<<<<<<<<<', file=filestream)
	
	# Try solving the root finding example problems
	for exnum, example in enumerate(examples):
		# Get data from example
		exname, function, derivative, roots, initial_guesses, initial_intervals = itemgetter('name', 'function', 'derivative', 'roots', 'initial_guesses', 'initial_intervals')(example)

		# Dump info on which problem is being considered
		print('\n>>>> Working on roots for "{:>10}".'.format(exname), file=filestream)
		
		# ------------------------ Run the bisection method
		if run_bisection:
			print('\n>>>> Applying bisection method', file=filestream)
			bisection_histories = []
			for interval_count, initial_interval in enumerate(initial_intervals):
				print('\n>>>> Working on initial_interval "[{: 1.3f}, {: 1.3f}]".'.format(*initial_interval), file=filestream)
				try:
					root, bisection_history = nls.bisection(function, initial_interval, bisection_options)
					bisection_histories.append((interval_count, bisection_history))
				except Exception as e:
					print(e, file=filestream)
		
		# ------------------------ Run the fixed point method
		if run_fixed_point:
			print('\n>>>> Applying fixed point iteration', file=filestream)
			fixed_point_histories = []
			for guess_count, initial_guess in enumerate(initial_guesses):
				print('\n>>>> Working with initial guess {: 1.3f}'.format(initial_guess), file=filestream)
				try:
					root, fixed_point_history = nls.fixed_point_iteration(lambda x: function(x) + x, initial_guess, fixed_point_options)
					fixed_point_histories.append((guess_count, fixed_point_history))
				except Exception as e:
					print(e, file=filestream)
				
		# ------------------------ Run Newton's method
		if run_newton:
			print('\n>>>> Applying local Newton\'s method', file=filestream)
			newton_histories = []
			for guess_count, initial_guess in enumerate(initial_guesses):
				print('\n>>>> Working with initial guess {: 1.3f}'.format(initial_guess), file=filestream)
				try:
					root, newton_history = nls.local_Newton(function, derivative, initial_guess, newton_options)
					newton_histories.append((guess_count,newton_history))
				except Exception as e:
					print(e, file=filestream)

		# Dump some output
		print('\nFinished computing roots for "{:>10}". Plotting errors'.format(exname), file = filestream)
	
		# Get colors for drawing
		colors = plt.rcParams['axes.prop_cycle'].by_key()['color']
	
		# ------------------------ Draw parameters of bisection
		if run_bisection  and len(bisection_histories) > 0:
			fig, ax = plt.subplots(1,1)
			# Plot left, right and center over iterations
			for (interval_count, history), clr in zip(bisection_histories, colors):
				ax.plot(history['l'], '--', color = clr)
				ax.plot(history['r'], '--', color = clr)
				ax.plot(history['x'], color = clr, label='x_0 = {:1.1f}'.format(initial_guesses[interval_count]))
			# Plot analytically computed roots
			for refroot in roots:
				plt.plot(np.arange(-1,len(history['l'])), refroot*np.ones(1+len(history['l'])), 'k--')
			# Decorate and save plot
			plt.title('Bisection parameters for {:}'.format(exname))
			plt.xlabel("Iteration")
			plt.ylabel("Interval parameters (lower, upper, center)")
			plt.legend()
			plt.savefig('../figures/048_bisection_parameters_{}.png'.format(exname))
	
		# ------------------------ Draw behavior of bisection in function graph
		if run_bisection and len(bisection_histories) > 0:
			fig, ax = plt.subplots(1,1)
			min_c, max_c = np.inf, -np.inf
			# Plot center iterates and compute largest and smallest iterate
			for (interval_count, history), clr in zip(bisection_histories, colors):
				if len(history['x']) > 0:
					min_c = min(min_c, min(history['x']))
					max_c = max(max_c, max(history['x']))	
					ax.plot(history['x'], function(np.asarray(history['x'])), 'o', color = clr, label='x_0 = {:1.1f}'.format(initial_guesses[interval_count]))
			# Set relative extansion of iterate interval beyond iterates
			plot_scale_factor = 0.1
			# Compute plot boundaries
			plot_bounds = (min_c -  plot_scale_factor*np.abs(max_c - min_c), max_c + plot_scale_factor*np.abs(max_c - min_c))
			# Set x-range of plot
			plot_range = np.linspace(*plot_bounds , 102)
			# Plot function and root level
			ax.plot(plot_range, function(plot_range))
			ax.plot(plot_range, np.zeros(len(plot_range)), 'k--')
			# Decorate and save graph
			plt.title('Bisection behavior for {:}'.format(exname))
			plt.xlabel("x")
			plt.ylabel("function values")
			plt.legend()
			plt.savefig('../figures/048_bisection_behavior_{}.png'.format(exname))
	
		# ------------------------ Draw behavior of fixed point iteration in function graph
		if run_fixed_point and len(fixed_point_histories) > 0:
			fig, ax = plt.subplots(1,1)
			min_x, max_x = np.inf, -np.inf
			# Plot center iterates and compute largest and smallest iterate
			for (guess_count, history), clr in zip(fixed_point_histories, colors):
				if len(history['x']) > 0:
					min_x = min(min_x, min(history['x']))
					max_x = max(max_x, max(history['x']))	
					ax.plot(history['x'], function(np.asarray(history['x'])), 'o', color = clr, label='x_0 = {:1.1f}'.format(initial_guesses[guess_count]))
			# Set relative extansion of iterate interval beyond iterates
			plot_scale_factor = 0.1
			# Compute plot boundaries
			plot_bounds = (min_x -  plot_scale_factor*np.abs(max_x - min_x), max_x + plot_scale_factor*np.abs(max_x - min_x))
			# Set x-range of plot
			plot_range = np.linspace(*plot_bounds, 102)
			# Plot function and root level
			ax.plot(plot_range, function(plot_range))
			ax.plot(plot_range, np.zeros(len(plot_range)), 'k--')
			# Decorate and save graph
			plt.title('Fixed point behavior for {:}'.format(exname))
			plt.xlabel("x")
			plt.ylabel("function values")
			plt.legend()
			plt.savefig('../figures/048_fixed_point_behavior_{}.png'.format(exname))
		
		# ------------------------ Draw behavior of Newton's method in function graph
		if run_newton and len(newton_histories) > 0:
			fig, ax = plt.subplots(1,1)
			min_x, max_x = np.inf, -np.inf
			# Plot center iterates and compute largest and smallest iterate
			for (guess_count, history), clr in zip(newton_histories, colors):
				if len(history['x']) > 0:
					min_x = min(min_x, min(history['x']))
					max_x = max(max_x, max(history['x']))	
					ax.plot(history['x'], function(np.asarray(history['x'])), 'o', color = clr, label='x_0 = {:1.1f}'.format(initial_guesses[guess_count]))
			# Set relative extansion of iterate interval beyond iterates
			plot_scale_factor = 0.1
			# Compute plot boundaries
			plot_bounds = (min_x -  plot_scale_factor*np.abs(max_x - min_x), max_x + plot_scale_factor*np.abs(max_x - min_x))
			# Set x-range of plot
			plot_range = np.linspace(*plot_bounds, 102)
			# Plot function and root level
			ax.plot(plot_range, function(plot_range))
			ax.plot(plot_range, np.zeros(len(plot_range)), 'k--')
			# Decorate and save graph
			plt.title('Newton behavior for {:}'.format(exname))
			plt.xlabel("x")
			plt.ylabel("function values")
			plt.legend()
			plt.savefig('../figures/048_newton_behavior_{}.png'.format(exname))
	
		# ------------------------ Draw convergence speeds
		fig, ax = plt.subplots(1,1)
		#Draw bisection
		if run_bisection and len(bisection_histories) > 0:
			for interval_count, history in bisection_histories:
				# If the run actually ran
				if len(history['x']) > 0:
					# Find the root that is closest to the final iterate
					abs_root_errors = np.abs(np.asarray(roots) - history['x'][-1])
					closest_root_index = np.argmin(abs_root_errors)
					refroot = roots[closest_root_index]
					abs_root_error = abs_root_errors[closest_root_index]
					
					# Check if there is any "reasonable" convergence to plot
					if abs_root_error < 1e-2:
						errors = np.abs(np.asarray(history['x']) - refroot)
						ax.plot(errors, label='Bisection for x_0 = {:1.1f}'.format(initial_guesses[interval_count]))
					
		if run_fixed_point and len(fixed_point_histories) > 0:
			for guess_count, history in fixed_point_histories:
				# If the run actually ran
				if len(history['x']) > 0:
					# Find the root that is closest to the final iterate
					abs_root_errors = np.abs(np.asarray(roots) - history['x'][-1])
					closest_root_index = np.argmin(abs_root_errors)
					refroot = roots[closest_root_index]
					abs_root_error = abs_root_errors[closest_root_index]
					
					# Check if there is any "reasonable" convergence to plot
					if abs_root_error < 1e-2:
						errors = np.abs(np.asarray(history['x']) - refroot)
						ax.plot(errors, label='FPI for x_0 = {:1.1f}'.format(initial_guesses[guess_count]))
						
		if run_newton and len(newton_histories) > 0:
			for guess_count, history in newton_histories:
				# If the run actually ran
				if len(history['x']) > 0:
					# Find the root that is closest to the final iterate
					abs_root_errors = np.abs(np.asarray(roots) - history['x'][-1])
					closest_root_index = np.argmin(abs_root_errors)
					refroot = roots[closest_root_index]
					abs_root_error = abs_root_errors[closest_root_index]
					
					# Check if there is any "reasonable" convergence to plot
					if abs_root_error < 1e-2:
						errors = np.abs(np.asarray(history['x']) - refroot)
						ax.plot(errors, label='Newton for x_0 = {:1.1f}'.format(initial_guesses[guess_count]))
		
		ax.set_yscale('log')
		plt.title('Convergence speeds for {:}'.format(exname))
		plt.xlabel("Iteration")
		plt.ylabel("Distance to root")
		plt.legend()
		plt.savefig('../figures/048_convergence_speeds_{}.png'.format(exname))
				
plt.show()
