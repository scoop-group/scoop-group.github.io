import numpy as np

def bisection(f, initial_guess, options):
	''' 
	Find root of function using bisection method
	TODO: Documentation
	'''
	
	# Define short hand for printing header in output blocks
	def print_header(s = ''):
		print(s + 'ITER        A_LEN        R_LEN          RES      ITERATE', file=options['filestream'])
		print('--------------------------------------------------------------------', file=options['filestream'])
	
	# Define empty container for history
	history = {
		'l': [],
		'r': [],
		'x': [],
		'fx': []
	}
	
	# Get left/right delimiter of initial interval and compute function values
	l, r =  min(*initial_guess), max(*initial_guess)
	fl, fr = f(l), f(r)
	
	# Check for special initialization cases
	if fl*fr > 0.0:
		raise ValueError('Bisection initialized with bad interval. Signs of function values on both ends coincide.')
	elif fl*fr == 0.0:
		print('One of the interval ends is a root. Returning one of them.', file=options['filestream'])
		return l, history if fl == 0.0 else r
	
	# Compute center and corresponding function value
	c = 0.5*(l + r)
	fc = f(c)
	
	# Set initial values for tracking
	iteration = 0
	interval_length = r-l
	rel_interval_length = interval_length/np.min((np.abs(l), np.abs(r))) if l*r!=0.0 else options["rTol"] + 1.0
	
	# Save initial parameters
	if options['keep_history']:
		history['l'].append(l)
		history['r'].append(r)
		history['x'].append(c)
		history['fx'].append(fc)
	
	# Dump some output
	if options['verbosity'] == 'verbose':
		print_header()
		print('{:> 4d}   {:> 1.3e}   {:> 1.3e}   {:> 1.3e}   {:> 1.3e}'.format(iteration, interval_length, interval_length/min((np.abs(l), np.abs(r))) if l*r != 0.0 else np.nan, fc, c), file=options['filestream'])
	
	while interval_length > options["aTol"] and rel_interval_length > options["rTol"] and fc != 0.0:
		iteration += 1
		
		# Decide which half of the interval to focus on next
		if fl * fc < 0.0:
			r, fr = c, fc
		else:
			l, fl = c, fc
	
		interval_length *= 0.5
		rel_interval_length = interval_length/np.min((np.abs(l), np.abs(r))) if l*r != 0.0 else options["rTol"] + 1.0
		
		# Compute new center and corresponding function value
		c = 0.5*(l + r)
		fc = f(c)
		
		if options['keep_history']:
			history['l'].append(l)
			history['r'].append(r)
			history['x'].append(c)
			history['fx'].append(fc)

		# Dump some output
		if options['verbosity'] == 'verbose':
			if (iteration%10 == 0): 
				print_header()
			print('{:> 4d}   {:> 1.3e}   {:> 1.3e}   {:> 1.3e}   {:> 1.3e}'.format(iteration, interval_length, interval_length/min((np.abs(l), np.abs(r))) if l*r != 0.0 else np.nan, fc, c), file=options['filestream'])

	return c, history 
	
def fixed_point_iteration(f, initial_guess, options):
	# Define short hand for printing header in output blocks
	def print_header(dim):
		print('ITER   ABS_UP_NRM   REL_UP_NRM      RES_NRM' + ('      ITERATE' if dim == 1 else '') , file=options['filestream'])
		print('--------------------------------------------------------------------', file=options['filestream'])
	
	# Define empty container for history
	history = {
		'x': [],
		'update': [],
		'residual': [],
	}
	
	dim = 1 if np.isscalar(initial_guess) else len(initial_guess) 
	
	# Set initial values
	x = initial_guess
	residual = f(x) - x
	residual_norm = np.linalg.norm(residual)
	update_norm = np.inf
	iteration = 0
	
	# Save some data
	if options['keep_history']: 
		history['x'].append(x)
		history['residual'].append(residual)

	# Dump some output
	if options['verbosity'] == 'verbose':
		print_header(dim)
		print('{:> 4d}                             {:> 1.3e}'.format(iteration, residual_norm) + ('   {:> 1.3e}'.format(x) if dim == 1 else ''), file=options['filestream'])
	
	# Loop iterations
	while update_norm > options['update_aTol'] and (update_norm/np.linalg.norm(x) > options['update_rTol'] if np.linalg.norm(x) > 0 else True) and residual_norm > options['residual_aTol'] and iteration < options['max_iter']:

		iteration += 1
		# remember old/previous iterate
		xOld = x
		
		# compute new iterate
		x = residual + x
		
		# compute update length
		update = x - xOld
		update_norm = np.linalg.norm(update)
		rel_update_norm = update_norm/np.linalg.norm(x) if np.linalg.norm(x) > 0 else np.nan
		
		# Compute residual
		residual = f(x) - x
		residual_norm = np.linalg.norm(residual)
		
		# Dump some output
		if options['verbosity'] == 'verbose':
			if (iteration%10 == 0): 
				print_header(dim)
			print('{:> 4d}   {:> 1.3e}   {:> 1.3e}   {:> 1.3e}'.format(iteration, update_norm, rel_update_norm, residual_norm) + ( '   {:> 1.3e}'.format(x) if dim==1 else ''), file=options['filestream'])
			
		# Save some data
		if options['keep_history']: 
			history['x'].append(x)
			history['residual'].append(residual)
			history['update'].append(update)
			
	return x, history

def local_Newton(f, df, initial_guess, options):
	
	# Define short hand for printing header in output blocks
	def print_header(dim):
		print('ITER   ABS_UP_NRM   REL_UP_NRM      RES_NRM' + ('      ITERATE' if dim == 1 else '') , file=options['filestream'])
		print('--------------------------------------------------------------------', file=options['filestream'])
	
	# Define empty container for history
	history = {
		'x': [],
		'update': [],
		'residual': [],
	}
	
	dim = 1 if np.isscalar(initial_guess) else len(initial_guess) 
	
	# Set initial values
	x = initial_guess
	residual = f(x)
	residual_norm = np.linalg.norm(residual)
	update_norm = np.inf
	iteration = 0
	
	# Save some data
	if options['keep_history']: 
		history['x'].append(x)
		history['residual'].append(residual)

	# Dump some output
	if options['verbosity'] == 'verbose':
		print_header(dim)
		print('{:> 4d}                             {:> 1.3e}'.format(iteration, residual_norm) + ('   {:> 1.3e}'.format(x) if dim == 1 else ''), file=options['filestream'])
	
	# Loop iterations
	while update_norm > options['update_aTol'] and (update_norm/np.linalg.norm(x) > options['update_rTol'] if np.linalg.norm(x) > 0 else True) and residual_norm > options['residual_aTol'] and iteration < options['max_iter']:

		iteration += 1

		# remember old/previous iterate
		xOld = x
		
		# compute new iterate

		derivative = df(x)
		if derivative == 0.0:
			raise ValueError('Newton encountered vanishing linearization')
		else:
			update = -residual/derivative if np.isscalar(x) else -np.linalg.solve(derivative, residual)
		x += update
		
		# compute update length
		update_norm = np.linalg.norm(update)
		rel_update_norm = update_norm/np.linalg.norm(x) if np.linalg.norm(x) > 0 else np.nan
		
		# Compute residual
		residual = f(x)
		residual_norm = np.linalg.norm(residual)
		
		# Dump some output
		if options['verbosity'] == 'verbose':
			if (iteration%10 == 0): 
				print_header(dim)
			print('{:> 4d}   {:> 1.3e}   {:> 1.3e}   {:> 1.3e}'.format(iteration, update_norm, rel_update_norm, residual_norm) + ( '   {:> 1.3e}'.format(x) if dim==1 else ''), file=options['filestream'])
			
		# Save some data
		if options['keep_history']: 
			history['x'].append(x)
			history['residual'].append(residual)
			history['update'].append(update)
			
	return x, history
