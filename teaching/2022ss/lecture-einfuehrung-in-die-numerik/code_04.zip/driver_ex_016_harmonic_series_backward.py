# script that sums up partial sum of harmonic series starting with smallest addands
import sys
import os
import numpy as np
import matplotlib.pyplot as plt

# Set output filestream name
output_filename = os.path.splitext(os.path.basename(__file__))[0] + '_output.txt'

# Open output filestream
with open(output_filename, 'w') as filestream:
	# Initialize history to check later
	history = {
				"harmonic_sum" : [],
				"increment" : [],
				}

	# Initialize partial sum for k = 1
	harmonic_sum = np.float32('0')

	# Initial sum for comparison arbitrarily
	old_sum = -np.float32('0')

	twice_elements = 2*2097152

	# Sum from small to large for double the numbers from naive approach
	for idx in np.arange(twice_elements,0,-1):
		# Compute increment
		increment = np.float32(1/idx)
		history["increment"].append(increment)
		
		# Dump some output
		if(idx % 100000 == 0):
			print("Sum is at {harmonic_sum:5e}. Adding {i:7d}-th increment {inc:3e}.".format(harmonic_sum=harmonic_sum, i=idx, inc=increment), file=filestream)
		
		# Remember last sum
		old_sum = harmonic_sum
		
		# Update sum
		harmonic_sum += increment
		history["harmonic_sum"].append(harmonic_sum)
		
		if(harmonic_sum == old_sum):
			print("\nTried adding 1/{i:}={increment:.5e} without change in sum.\nValue of harmonic sum is {val:.5f}.".format(increment=increment,idx=idx), file=filestream) 
			exit();

	# Output
	print("\nAdded all {twice_elements} elements. Value of harmonic sum is {val:.5f}.".format(twice_elements = twice_elements, val = harmonic_sum), file = filestream)

	plt.figure()
	plt.plot(history["harmonic_sum"])
	plt.title('Value of harmonic sum over iterates')
	plt.xlabel('Iterates')
	plt.ylabel('Harmonic sum')
	plt.savefig('../figures/harmonic_sum_value_backwards.png')

	plt.figure()
	plt.semilogy(history["increment"])
	plt.title('Increments over iterates')
	plt.xlabel('Iterates')
	plt.ylabel('Harmonic sum')
	plt.savefig('../figures/harmonic_sum_increments_backwards.png')
