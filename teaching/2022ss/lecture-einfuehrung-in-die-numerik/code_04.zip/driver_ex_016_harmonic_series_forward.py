# script that sums up harmonic series until numerics see no change in sum value
import os
import numpy as np
import matplotlib.pyplot as plt

# Set output filestream name
output_filename = os.path.splitext(os.path.basename(__file__))[0] + '_output.txt'

# Open output filestream
with open(output_filename, 'w') as filestream:
	print("######### Starting naive computation #########", file=filestream)

	# Initialize history to check later
	history = {
				"harmonic_sum" : [],
				"increment" : [],
				}

	# Initialize partial sum for k = 1
	harmonic_sum = np.float32('0')

	# Initial sum for comparison arbitrarily
	old_sum = - np.inf

	# Initialize counter to compute increment
	i = 0

	# While change is still detected
	while (harmonic_sum != old_sum):
		# Update counter
		i += 1
		
		# Compute incerement
		increment = np.float32(1/i)
		history["increment"].append(increment)
		
		# Dump some output
		if(i % 100000 == 0):
			print("Sum is at {harmonic_sum:5e}. Adding {i:7d}-th increment {inc:3e}.".format(harmonic_sum=harmonic_sum, i=i, inc=increment), file=filestream)
		
		# Remember last sum
		old_sum = harmonic_sum
		
		# Update sum
		harmonic_sum += increment
		history["harmonic_sum"].append(harmonic_sum)

	# Output
	print("\nTried adding 1/{i:}={inc:.5e} without change in sum.\nValue of harmonic sum is {val:.5f}.".format(i=i, val=harmonic_sum, inc=increment), file=filestream)

	filestream.close()

	plt.figure()
	plt.plot(history["harmonic_sum"])
	plt.title('Value of harmonic sum over iterates')
	plt.xlabel('Iterates')
	plt.ylabel('Harmonic sum')
	plt.savefig('../figures/harmonic_sum_value_naiv.png')

	plt.figure()
	plt.semilogy(history["increment"])
	plt.title('Increments over iterates')
	plt.xlabel('Iterates')
	plt.ylabel('Harmonic sum')
	plt.savefig('../figures/harmonic_sum_increments_naiv.png')
