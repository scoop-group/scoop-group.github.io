# Script that tests the LR factorization on the two 3x3 examples in the script
import sys
import os
import numpy as np
import pivot_functions as pivs
from lr_implementation_tests import check_script_examples
np.seterr(all='raise')

# Set output filestream name
output_filename = os.path.splitext(os.path.basename(__file__))[0] + '_output.txt'

# Set pivot types we want to check
pivots = [pivs.no_pivot, pivs.column_pivot, pivs.row_pivot, pivs.total_pivot, pivs.inverse_total_pivot]

# Open output filestream
with open(output_filename, 'w') as filestream:
	# Check examples
	print(">>>>>>>>>>>>>>>>>>>>>> Testing LR solver on small known systems from script <<<<<<<<<<<<<<<<<<<<<<<", file=filestream)
	check_script_examples(pivots, filestream)
