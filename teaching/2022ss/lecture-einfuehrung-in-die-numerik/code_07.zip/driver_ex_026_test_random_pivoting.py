# Script that compares the relative errors when solving random linear systems of equations using LR factorization for random total pivoting and total pivoting
import sys
import os
import numpy as np
import matplotlib.pyplot as plt
import linear_solvers as ls
import pivot_functions as pivs
from lr_implementation_tests import generate_random_testmatrix
np.seterr(all='raise')
#import pdb

# Set output filestream name
output_filename = os.path.splitext(os.path.basename(__file__))[0] + '_output.txt'

# Get random number generator
rng = np.random.default_rng(seed = 10)

# Set parameters
dim_bound = 100
upper_element_bound = 1e15
samples = 500

# Set pivot types that we want to check
pivots = [pivs.total_pivot, pivs.random_total_pivot]
pivots.reverse()

# Set relative number of bad pivoting elements in a row
alpha = 0.25

# Open output filestream
with open(output_filename, 'w') as filestream:
		print(">>>>>>>>>>>>>>>>>>>>>> Testing LR solver with random pivoting against total pivoting <<<<<<<<<<<<<<<<<<<<<<<", file=filestream)
		
		dims = []
		sample_rel_errors = []
		for sample in range(samples):
			# Get random dimension of problem
			dim = rng.integers(3, dim_bound)
			
			# Compute number of bad pivot elements to set
			nr_of_bad_pivots_per_row = int(max(1.0,int(np.floor(alpha * dim))))

			# Dump some output
			print("\n>>>>>>>>>> Sample {: d} - Solving a(n) {: d}-dimensional problem".format(sample, dim), file = filestream)
			
			# Generate a random A of integers
			A = generate_random_testmatrix(upper_element_bound, dim, nr_of_bad_pivots_per_row, rng)

			# Fix solution
			x = np.ones(dim, dtype = float)
			
			# Generate right hand side to fixed solution
			b = A @ x
			
			sample_pivot_rel_errors = []
			for pivot in pivots:
				try:
					# Instantiate solver without pivoting and factorize
					lrs = ls.LRSolver(A, pivot)
					
					# Factorize
					lrs.factorize()
					
					# Solve
					sol = lrs.solve(b)
					
					# Get rel error
					sample_pivot_rel_errors.append(np.linalg.norm(x-sol)/np.linalg.norm(x))
					
					# Print info
					print("Relative 2-norm-error of solution using {:>16}: {:1.3e}".format(pivot.__name__,
						sample_pivot_rel_errors[-1]), file=filestream)
					
				except Exception as e:
					print('Trying to factorize with pivoting rule "{}" throws Error: "{}"'.format(pivot.__name__, str(e)), file=filestream)
					sample_pivot_rel_errors.append(-1.0)
			
			# remember results
			sample_rel_errors.append(sample_pivot_rel_errors)
			dims.append(dim)
			
#Plot the results
fig, ax = plt.subplots(figsize = (8,8))
pivot_errors = [[piv_ers[i] for piv_ers in sample_rel_errors] for i in range(len(pivots))]

# Check performance
with open(output_filename, 'a') as filestream:
	if len(pivots) == 2:
		err_0 = np.array(pivot_errors[0])
		err_1 = np.array(pivot_errors[1])
		
		no_fails = np.logical_and(err_0 >= 0, err_1 >= 0)
		
		err_0 = err_0[no_fails]
		err_1 = err_1[no_fails]
		
		outperformed = err_0 < err_1
		print('\nRule "{}" outperformed "{}" {: d} out of {: d} times. '.format(pivots[0].__name__, pivots[1].__name__, np.count_nonzero( outperformed ), samples ), file=filestream)
		
		relative_deviation = np.abs(err_0[np.logical_and(outperformed,err_1 != 0)] - err_1[np.logical_and(outperformed,err_1 != 0)])/np.abs(err_1[np.logical_and(outperformed,err_1 != 0)])
		print('Relative improvement of relative error:\n', relative_deviation, file=filestream)

# scatter the data for each pivoting method
for i in range(len(pivots)):
	x = np.array(dims)
	y = np.array(pivot_errors[i])
	ax.scatter(x[y>0], y[y>0], s=60, alpha=0.7, edgecolors="k")
	ax.set_yscale("log")

plt.title('Relative errors in random LR-solving')
plt.legend([pivot.__name__ for pivot in pivots])
plt.xlabel('Matrix dimension')
plt.ylabel('Relative error of solutions')

#plt.show()
plt.savefig('../figures/LR_random_pivoting.png')
