# Script that tests the LR factorization on the two 3x3 examples in the script
import sys
import os
import numpy as np
import pivot_functions as pivs
import linear_solvers as ls
from lr_implementation_tests import generate_random_testmatrix, check_random_examples
np.seterr(all='raise')

# Set output filestream name
output_filename = os.path.splitext(os.path.basename(__file__))[0] + '_output.txt'

# Set pivots we want to check
pivots = [pivs.no_pivot, pivs. column_pivot, pivs.row_pivot, pivs.total_pivot, pivs.inverse_total_pivot]

# Open output filestream
with open(output_filename, 'w') as filestream:
	print(">>>>>>>>>>>>>>>>>>>>>> Testing LR solver without pivoting for random matrices <<<<<<<<<<<<<<<<<<<<<<<", file=filestream)
	check_random_examples(pivots, filestream)
