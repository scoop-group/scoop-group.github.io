# Script that shows the dependence of relative error in solution of lin systems by LU factorization on the number of bad pivoting elements
import sys
import os
import numpy as np
import matplotlib.pyplot as plt
import linear_solvers as ls
import pivot_functions as pivs
from lr_implementation_tests import generate_random_testmatrix
np.seterr(all='raise')

# Set output filestream name
output_filename = os.path.splitext(os.path.basename(__file__))[0] + '_output.txt'

# Get random number generator
rng = np.random.default_rng(seed = 10)

# Set parameters
dim_bound = 300
upper_element_bound = 1e20
samples = 100

# initialize containers
max_errors = []
min_errors = []

alphas = [0, 0.3, 0.6, 0.9]
alphas.reverse()

# Open output filestream
with open(output_filename, 'w') as filestream:
	print(">>>>>>>>>>>>>>>>>>>>>> Testing LR solver without pivoting for random matrices <<<<<<<<<<<<<<<<<<<<<<<", file=filestream)
	
	alpha_errors = []
	alpha_dims = []
	for alpha in alphas:
		
		rel_errors = []
		dims = []
		for sample in range(samples):
			# Get random dimension of problem
			dim = rng.integers(3, dim_bound)
			nr_of_bad_pivots_per_row = int(max(1.0,int(np.floor(alpha * dim))))

			# Dump some output
			print("\n>>>>>>>>>> Alpha = {:f}, sample {: d} - Solving a(n) {: d}-dimensional problem".format(alpha, sample, dim), file = filestream)
			
			# Generate a random A of integers
			A = generate_random_testmatrix(upper_element_bound, dim, nr_of_bad_pivots_per_row, rng)

			# Fix solution
			x = np.ones(dim, dtype = float)
			
			# Generate right hand side to fixed solution
			b = A @ x
			
			try:
				# Instantiate solver without pivoting and factorize
				lrs = ls.LRSolver(A, pivs.no_pivot)
				
				# Factorize
				lrs.factorize()
				
				# Solve
				sol = lrs.solve(b)
				
				# Get rel error
				rel_errors.append(np.linalg.norm(x-sol)/np.linalg.norm(x))
				
				# Print info
				print("Relative 2-norm-error of solution using {}: {:1.3e}".format(pivs.no_pivot.__name__,
					rel_errors[-1]), file=filestream)
				
			except Exception as e:
				print('Trying to factorize with pivoting rule "{}" throws Error: "{}"'.format(pivs.no_pivot.__name__, str(e)), file=filestream)
				rel_errors.append(-1.0)
			dims.append(dim)
			
		# remember results
		alpha_errors.append(rel_errors)
		alpha_dims.append(dims)
	#Plot the results
	fig, ax = plt.subplots(figsize = (8,8))

	# scatter the data for each pivoting method
	mean_errors = []
	median_errors = []
	for i in range(len(alphas)):
		x = np.array(alpha_dims[i])
		y = np.array(alpha_errors[i])
		mean_errors.append(np.mean(y[y>0]))
		median_errors.append(np.median(y[y>0]))
		print('Mean   error for alpha = {:1.3e} is {:1.3e}'.format(alphas[i], mean_errors[-1]), file=filestream)
		print('Median error for alpha = {:1.3e} is {:1.3e}'.format(alphas[i], median_errors[-1]), file=filestream)
		ax.scatter(x[y>0], y[y>0], s=60, alpha=0.7, edgecolors="k")
		ax.set_yscale("log")
		#plt.ylim(min(y), max(y))

	plt.title('Relative errors in random LR-solving')
	plt.legend([str(alpha) for alpha in alphas])
	plt.xlabel('Matrix dimension')
	plt.ylabel('Relative error of solutions')
	plt.savefig('../figures/LR_bad_pivot_dependence_scatter.png')

	fig, ax = plt.subplots(figsize = (8,8))
	plt.title('Relative errors depending on alpha')
	ax.plot(alphas, mean_errors)
	ax.plot(alphas, median_errors)
	ax.set_yscale("log")
	plt.legend(['median error', 'mean error'])
	plt.xlabel('Relative number of bad pivots in row')
	plt.ylabel('Relative errors')
	plt.savefig('../figures/LR_bad_pivot_dependence.png')
