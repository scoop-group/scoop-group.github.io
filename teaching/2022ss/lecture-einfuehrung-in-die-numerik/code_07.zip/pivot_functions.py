import numpy as np
import warnings
#import pdb

def no_pivot(MAT, p, q, step):
	''' do nothing'''
	return None

def column_pivot(MAT, p, q, step):
	''' In the column specified by step, find abs-value largest element below diagonal, permute entire matrix so row step is switched with said row. Permute p the same way, leave q untouched because no row pivoting is used.'''
	
	#Find row index of a larges element in current remainder column and map to global index (add step)
	pivot_index = np.argmax(np.abs(MAT[step:, step])) + step
	
	if np.isclose(MAT[pivot_index,step], 0):
		warnings.warn("Pivoting element is close to zero.")
	
	# Swap pivot row with step row and remember operation in vector p
	MAT[[step, pivot_index],:] = MAT[[pivot_index, step],:]
	p[[step, pivot_index]] = p[[pivot_index, step]]
	
	return None

def row_pivot(MAT, p, q, step):
	''' In the row specified by step, find abs-value largest element right of diagonal, permute entire matrix so column step is switched with said column. Permute q the same way, leave p untouched because no column pivoting is used.'''
	
	#Find row index of a larges element in current remainder column and map to global index (add step)
	pivot_index = np.argmax(np.abs(MAT[step, step:])) + step
	
	if np.isclose(MAT[pivot_index,step], 0):
		warnings.warn("Pivoting element is close to zero.")
	
	# Swap pivot col with step col and remember operation in vector p
	MAT[:, [step, pivot_index]] = MAT[:, [pivot_index, step]]
	q[[step, pivot_index]] = q[[pivot_index, step]]
	return None

def total_pivot(MAT, p, q, step):
	''' In the square submatrix MAT[step:,step:] (lower right corner), find abs-value largest element, permute entire matrix so MAT[step,step] is swapped to the location of said element. Permute q as rows were permuted, Permute q as columns were permuted.'''
	
	dim = MAT.shape[0]
	
	#Find indices of an abs larges element in current remainder submatrix and map to global indices (add step)
	row_pivot_index, column_pivot_index = tuple(x+step for x in np.unravel_index(np.argmax(np.abs(MAT[step:, step:]), axis=None), (dim-step, dim-step)))
	
	if np.isclose(MAT[row_pivot_index,column_pivot_index], 0):
		warnings.warn("Pivoting element is close to zero.")
	
	# Swap pivot row with step row and pivot col with step col and remember operation in vectors p,q
	MAT[[step, row_pivot_index],:] = MAT[[row_pivot_index, step],:]
	MAT[:, [step, column_pivot_index]] = MAT[:, [column_pivot_index, step]]
	p[[step, row_pivot_index]] = p[[row_pivot_index, step]]
	q[[step, column_pivot_index]] = q[[column_pivot_index, step]]
	return None

def inverse_total_pivot(MAT, p, q, step):
	''' In the square submatrix MAT[step:,step:] (lower right corner), find abs-value smallest nonzero element, permute entire matrix so MAT[step,step] is swapped to the location of said element. Permute q as rows were permuted, Permute q as columns were permuted.'''
	
	dim = MAT.shape[0]
	
	#Find indices of an abs smalles nonzero element in current remainder submatrix and map to global indices (add step)
	abs_lower_right = np.abs(MAT[step:, step:])
	unshifted_indices = tuple(np.where( abs_lower_right == np.min(abs_lower_right[np.nonzero(abs_lower_right)]))[i][0] for i in range(2))
	row_pivot_index, column_pivot_index = tuple(x+step for x in unshifted_indices)
	
	if np.isclose(MAT[row_pivot_index,column_pivot_index], 0):
		warnings.warn("Pivoting element is close to zero.")
	
	# Swap pivot row with step row and pivot col with step col and remember operation in vectors p,q
	MAT[[step, row_pivot_index],:] = MAT[[row_pivot_index, step],:]
	MAT[:, [step, column_pivot_index]] = MAT[:, [column_pivot_index, step]]
	p[[step, row_pivot_index]] = p[[row_pivot_index, step]]
	q[[step, column_pivot_index]] = q[[column_pivot_index, step]]
	return None

def random_total_pivot(MAT, p, q, step):
	''' In the square submatrix MAT[step:,step:] (lower right corner), find nonzero elements, pick one at random, permute entire matrix so MAT[step,step] is swapped to the location of said element. Permute q as rows were permuted, Permute q as columns were permuted.'''
	
	dim = MAT.shape[0]
	
	# Make random number generator
	rng = np.random.default_rng(seed = 0)
	
	# Find nonzero entries
	nonzeros_in_lower_right = np.where( MAT[step:, step:] != 0 )
	# Pick random index among nonzeros
	random_index = rng.integers(low=0, high=len(nonzeros_in_lower_right[0]), size=1)[0]
	
	# Make matrix indices
	row_pivot_index, column_pivot_index = tuple(nonzeros_in_lower_right[i][random_index] + step for i in range(2))
	
	if np.isclose(MAT[row_pivot_index,column_pivot_index], 0):
		warnings.warn("Pivoting element is close to zero.")
	
	# Swap pivot row with step row and pivot col with step col and remember operation in vectors p,q
	MAT[[step, row_pivot_index],:] = MAT[[row_pivot_index, step],:]
	MAT[:, [step, column_pivot_index]] = MAT[:, [column_pivot_index, step]]
	p[[step, row_pivot_index]] = p[[row_pivot_index, step]]
	q[[step, column_pivot_index]] = q[[column_pivot_index, step]]
	return None
