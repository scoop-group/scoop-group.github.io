import numpy as np
import pivot_functions as pivs
import qr_factorizers as qrs

# Interface for linear solvers (most abstract)
class LinearSolver():
	def __init__(self, _A: np.array):
		pass
		
	def setup(self, _A: np.array) -> None:
		self.A = _A
		pass
	
	def solve(self, B: np.array) -> np.array:
		pass
	
# Interface for direct linear solvers (mid-level abstraction)
# inherits "init" and "solve"
class DirectLinearSolver(LinearSolver):
	pass

# Interface for iterative linear solvers (mid-level abstraction)
class IterativeLinearSolver(LinearSolver):
	def __init__(self, _A: np.array, _maxsteps: int, _tolerance: float):
		super().__init__(self, _A)
		self.maxsteps = _maxsteps
		self.tolerance = _tolerance
		
	def setTol(self, _tolerance: float) -> None:
		self.tolerance = _tolerance
		return None
	
	def setMaxSteps(self, _maxsteps: int) -> None:
		self.maxsteps = _maxsteps
		return None
	
# Actual class for LR solvers (we use LR instead LU for consistency with lecture notes notation)
class LRSolver(DirectLinearSolver):
	'''
	This class implements direct solving of linear systems of equations Ax=b in finite dimensions by LR-factorizing 
	the system matrix using Gaussian elimination and solving by backward-/forward-substitution.
	
	The Matrix A is initially copied and the factorization is done on the copy in place.
	This is so we can use the initial matrix A for comparisons later on.
	'''
	
	# Create solver
	def __init__(self, _A, _pivot = pivs.column_pivot):
		# Check if matrix A is square
		if _A.shape[0] != _A.shape[1]:
			exit("Input matrix is not rectangular")
		self.dim = _A.shape[0]

		super().__init__(_A)
		self.pivot = _pivot

		# Set up solver data
		self.setup(_A,_pivot)
		return None
	
	# Set up solver for a matrix
	def setup(self, _A, _pivot = pivs.column_pivot) -> None:
		# Call super class setup (store A in solver object)
		super().setup(_A)
		self.pivot = _pivot
		self.factorized = False
		return None
	
	# Set pivoting rule
	def set_pivot(self, pivot) -> None:
		self.pivot = pivot
		self.factorized = False
		return None
	
	# Method that returns L, R and P such that PA = LR (creates extra matrices from optimized storage)
	def getLRPQT(self):
		if not self.factorized:
			self.factorize()
		
		L = np.tril(self.LR, -1) + np.eye(self.dim)
		R = np.triu(self.LR)
		
		# Create permutation matrices from permutation vectors
		P = np.zeros((self.dim, self.dim), dtype=int)
		P[range(self.dim),self.p] = 1
		QT = np.zeros((self.dim, self.dim), dtype=int)
		QT[self.q,range(self.dim)] = 1
		
		return L, R, P, QT
	
	def factorize(self) -> None:
		# Factorize LR in place
		
		# Copy initial matrix 
		self.LR = self.A.copy()
		self.p = np.arange(self.dim)
		self.q = np.arange(self.dim)
		
		for step in range(self.dim - 1):
			# Pivot current LR matrix
			self.pivot(self.LR, self.p, self.q, step)

			# Get inverse of pivot element
			inverse_pivot_element = 1.0/self.LR[step,step]

			# write the new L entries by scaling the leading entries of each row by inverse pivot element
			self.LR[step+1:, step] = self.LR[step+1:, step]*inverse_pivot_element

			# Update lower right corner of LR
			#for row in range(step+1,self.dim):
				#for col in range(step+1,self.dim):
					#self.LR[row,col] -= self.LR[step,col]*self.LR[row,step]
					
			# <COMMENT 
			# The update is actually equivalent to 
			update = - np.outer(self.LR[step+1:, step], self.LR[step, step+1:])
			self.LR[step+1:,step+1:] += update
			# Which assembles a full matrix that needs tons of storage though, so the in place LR really make no sense if you do this
			# COMMENT>
			
		
		self.factorized = True
		return None
		
	def solve(self, B: np.array) -> np.array:
		# Special forward substitution for L encoded in LR Matrix
		def Lforward(LR, B):  
			dim = LR.shape[0]
			# Get number of right hand sides
			n_rhs = B.shape[1]
			
			sub = np.empty((dim, n_rhs), dtype=float)
			for step in range(dim):
				# pythonic compact notation 
				#sub[step,:] = (B[step,:] - sum([LR[step, j] * sub[j,:] for j in range(step)]))
				# explicitly rolling the sum starting at diagonal going to outside
				sub[step,:] = B[step,:]
				for j in range(step-1,-1,-1):
					sub[step,:] -= LR[step, j] * sub[j,:]
			return sub
			
		# Backward substitution for upper triangular matrix
		def Rbackward(LR, B): 
			dim = np.shape(LR)[0]
			# Get number of right hand sides
			n_rhs = np.shape(B)[1]
			
			sub = np.empty((dim, n_rhs), dtype=float)
			for step in range(dim - 1, -1, -1):
				# pythonic compact notation 
				#sub[step,:] = (B[step,:] - sum([LR[step, j] * sub[j,:] for j in range(step + 1, dim)])) / LR[step, step]
				# explicitly rolling the sum starting at diagonal going to outside
				sub[step,:] = B[step,:]
				for j in range(step+1,dim):
					sub[step,:] -= LR[step, j] * sub[j,:]
				sub[step,:] /= LR[step, step]
			return sub

		# If B was an array with only one axis, give it a dummy one
		input_was_vector = False
		if len(B.shape)<2:
			input_was_vector = True
			B = np.atleast_2d(B).T

		# Get number of right hand sides
		n_rhs = B.shape[1]

		# Make sure we have the factorization
		if not self.factorized:
			self.factorize()
			
		# get solution by forward-backward substitution with permutation of input and inverse permutation of output
		sol = np.empty((self.dim, n_rhs), dtype=float)
		sol[self.q,:] = Rbackward(self.LR, Lforward(self.LR, B[self.p,:]))
		
		# remove dummy axis if it was added
		if input_was_vector:
			sol = sol[:,0]
		return sol

# Actual class for QR solvers
class QRSolver(DirectLinearSolver):
	'''
	This class implements direct solving of linear systems of equations Ax=b in finite dimensions by QR-factorizing 
	the system matrix using provided factorization algorithm and backward substitution.
	'''
	
	# Create solver
	def __init__(self, _A, _factorizer = qrs.Householder_QR):
		super().__init__(_A)

		# Set up solver data
		self.setup(_A, _factorizer)
		return None
	
	# Set up solver for a matrix
	def setup(self, _A, _factorizer = qrs.Householder_QR) -> None:
		# Call super class setup (store A in solver object)
		super().setup(_A)
		
		self.factorizer = _factorizer(_A)
		return None
	
	# Set factorizer
	def set_factorizer(self, _factorizer) -> None:
		self.factorizer = _factorizer(self.A)
		return None
	
	# Return Q and R such that A = QR (potentially create extra matrices from optimized storage)
	def get_QR(self):
		return self.factorizer.get_Q(), self.factorizer.get_R()
	
	def factorize(self) -> None:
		self.factorizer.factorize()
		return None

	# Backward substitution for upper triangular matrix
	def Rbackward(self, R, B): 
			dim = np.shape(R)[0]
			# Get number of right hand sides
			n_rhs = np.shape(B)[1]
			
			sub = np.empty((dim, n_rhs), dtype=float)
			for step in range(dim - 1, -1, -1):
				# pythonic compact notation 
				#sub[step,:] = (B[step,:] - sum([LR[step, j] * sub[j,:] for j in range(step + 1, dim)])) / LR[step, step]
				# explicitly rolling the sum starting at diagonal going to outside
				sub[step,:] = B[step,:]
				for j in range(step+1,dim):
					sub[step,:] -= R[step, j] * sub[j,:]
				sub[step,:] /= R[step, step]
			return sub

	def solve(self, B: np.array) -> np.array:
		# If B was an array with only one axis, give it a dummy one
		input_was_vector = False
		if len(B.shape)<2:
			input_was_vector = True
			B = np.atleast_2d(B).T

		# Get number of right hand sides
		n_rhs = B.shape[1]

		# Make sure we have the factorization
		if not self.factorizer.get_factorized():
			self.factorizer.factorize()
		
		# get solution by forward-backward substitution with permutation of input and inverse permutation of output
		sol = self.Rbackward(self.factorizer.get_R(), self.factorizer.apply_QT(B))
		
		# remove dummy axis if it was added
		if input_was_vector:
			sol = sol[:,0]
		return sol
