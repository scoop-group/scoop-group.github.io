''' 
Script that examins the error of the three different polynomial interpolation bases (Monomial, Lagrange, Newton) for data that should be hard to reconstruct using the monomial basis (Date is the last left singular value vector in svd decomposition of vandermond matrix and the condition of the vandermonde is increased along the way by shifting the supports away from 0 towards infty)

The errors observed may not necessarily be due to the bad reconstruction of the coefficients but due to the error introduced in the evaluations.
It flutters too much.
'''

import sys
import os
import numpy as np
import matplotlib.pyplot as plt
import interpolators as ips
np.seterr(all='raise')

print_interpols = True
#print_interpols = not print_interpols

# Set output filestream name
output_filename = os.path.splitext(os.path.basename(__file__))[0] + '_output.txt'

# Open output filestream
with open(output_filename, 'w') as filestream:

	print(">>>>>>>>>>>>>>>>>>>>>> Solving interpolation problems for shifted supports using three bases <<<<<<<<<<<<<<<<<<<<<<<", file=filestream)
	
	# Set polynomial degree
	degree = 5
	print("\n>>>>>>>>>> Polynomial degree set to = {: 3d} \n".format(degree), file = filestream)

	# Set the initial unshifted interval
	interval = (0.1, 1.1)
	supports = np.linspace(*interval, degree + 1)
	
	# Set interpolators to be compared
	interpolators = [ips.MonomialInterpolator, ips.LagrangeInterpolator, ips.NewtonInterpolator]

	# Make container for maximum relative errors
	max_rel_errors=[[] for interpolator in interpolators]
	
	# Discretize shifting up to max_shift
	max_shift = 300
	#shift_steps = 150
	shift_steps = 5
	shifts = np.linspace(0, max_shift, shift_steps)
	
	for shift in shifts:
		# Shift the interval
		shifted_interval = tuple(x + shift for x in interval)
		shifted_supports = np.array([x + shift for x in supports])
		
		# Build Vandermonde Matrix
		A = np.vander(shifted_supports, increasing = True)
		vander_cond = np.linalg.cond(A)
		
		print("\n>>>>>>>>>> Working on shift = {: 1.3f}, Condition of Vandermonde matrix is {: 1.3e}\n".format(shift, vander_cond), file = filestream)

		# Compute SVD decomp of A
		U, S, VT = np.linalg.svd(A)

		# Set data to reconstruct to whatever spans the subspace corresponding to smallest singular value
		data = U[:,-1]
		
		# Enlarge the plot interval
		alpha = 0.
		plot_interval = tuple(x - (np.diff(shifted_interval)[0])*((-1)**i)*alpha for i, x in enumerate(shifted_interval))
		
		# Make supports in the plot interval to evaluate error on
		plot_supports = np.linspace(*plot_interval, 150)
		
		if print_interpols:
			# Scatter data
			shifted_figure = plt.figure()
			plt.scatter(shifted_supports, data)
			plt.xlabel("t")
			plt.ylabel("data and reconstructed polys")
		
		for i, _interpolator in enumerate(interpolators):
			print("Applying {}".format(_interpolator.__name__), file = filestream)

			# Make interpolator
			interpolator = _interpolator(shifted_supports, data)
			
			# Evaluate the interpolated polynomial at the plot supports
			data_reconstructed = interpolator.evaluate(shifted_supports)
			plot_data_reconstructed = interpolator.evaluate(plot_supports)
			
			if print_interpols:
				# Plot interpolation polynomial
				plt.figure(shifted_figure.number)
				plt.plot(plot_supports, plot_data_reconstructed)
			
			# Compute Errors
			try:
				abs_error = np.abs(data - data_reconstructed)
				rel_error = abs_error / np.abs(data)
				max_error = np.max(abs_error)
				max_rel_error = np.max(rel_error)
				max_rel_errors[i].append(max_rel_error)
			except Exception as e:
				max_rel_errors[i].append(-1)
		
		if print_interpols:
			# Add info to plot of computed polnomial
			plt.figure(shifted_figure.number)
			plt.legend([interpolator.__name__ for interpolator in interpolators] + ['data'])
			plt.title('Interpolation for shift ={: 1.3f}'.format(shift))

			
	print("\nFinished interpolation. Plotting nonzero errors", file = filestream)
	fig, ax = plt.subplots(1,1)
	legend_names = []
	for i, interpolator in enumerate(interpolators):
		nonzero_errors = np.array(max_rel_errors[i]) > 0
		if np.any(nonzero_errors):
			ax.plot(np.array(shifts)[nonzero_errors], np.array(max_rel_errors[i])[nonzero_errors])
			ax.set_yscale('log')
			legend_names.append(interpolator.__name__)
		else:
			print("No nonzero errors for {}".format(interpolator.__name__), file = filestream)
		
	plt.title('Max. rel. error of data and computed polynomial at supports')
	plt.xlabel("Shift")
	plt.ylabel("Maximum relative error")
	plt.legend(legend_names)

	#plt.show()
