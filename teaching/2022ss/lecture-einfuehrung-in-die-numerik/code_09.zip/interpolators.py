import numpy as np

# Horner scheme for evaluating polynomials
def poly_eval_horner(coefficients, t):
	if np.isscalar(t):
		val = 0.0
	else:
		val = np.zeros(t.shape, dtype = float)
	for coefficient in reversed(coefficients):
		val *= t
		val += coefficient
	return val

# Interface for polynomial interpolators
class PolynomialInterpolator():
	def __init__(self, supports: np.array, data: np.array):
		pass
		
	def interpolate(self, supports, data) -> None:
		pass
	
	def evaluate(self, t) -> np.array:
		pass

class MonomialInterpolator(PolynomialInterpolator):
	'''Polynomial interpolation based on monomial basis and solving the Vandermonde-Matrix system'''
	def __init__(self, supports: np.array, data: np.array, solve_linear = np.linalg.solve):
		self.interpolate(supports, data, solve_linear)
		return None
	
	def interpolate(self, supports, data, solve_linear):
		A = np.vander(supports, increasing = True)
		self.coefficients = solve_linear(A, data)
		
	def evaluate(self, t):
		return np.vectorize(lambda t: poly_eval_horner(self.coefficients, t))(t)

class LagrangeInterpolator(PolynomialInterpolator):
	'''Polynomial interpolation based on Lagrange basis polynomials with barycentric weights'''
	def __init__(self, supports: np.array, data: np.array):
		self.interpolate(supports, data)
		self.evaluate = np.vectorize(self.evaluate_single)
		return None

	def interpolate(self, supports, data):
		self.omega = np.ones(supports.shape, dtype = float)
		# compute bary weights
		for i in range(len(supports)):
			for j in range(len(supports)):
				if i!=j:
					self.omega[i]/= supports[i] - supports[j]
		self.data = data
		self.supports = supports
	
	def evaluate_single(self, t):
		# Evaluate polynomial for single input (non-vector)
		equals_support = np.where(self.supports == t)
		if equals_support[0].size:
			#return data value
			val = self.data[equals_support[0][0]]
		else:
			tmp = self.omega / (t - self.supports)
			val = np.sum(self.data * tmp) / np.sum(tmp)
		return val

class NewtonInterpolator(PolynomialInterpolator):
	'''Polynomial interpolation based on Newton basis polynomials with divided differences'''
	def __init__(self, supports: np.array, data: np.array):
		self.interpolate(supports, data)
		return None

	def interpolate(self, supports, data):
		# Compute divided differences
		self.Y = np.zeros(tuple(len(supports) for i in range(2)), dtype = float)
		for k in range(len(supports)):
			self.Y[k,0] = data[k]
			for l in range(1, k+1):
				self.Y[k-l, l] = (self.Y[k-l+1, l-1] - self.Y[k-l][l-1]) / (supports[k] - supports[k-l])
		self.supports = supports
		
	def evaluate(self, t):
		val = self.Y[0,-1] * np.ones(t.shape, dtype = float)
		# Evaluate using horner type scheme
		for k in range(len(self.supports) - 2, -1, -1):
			val *= t - self.supports[k]
			val += self.Y[0,k]
		return val
