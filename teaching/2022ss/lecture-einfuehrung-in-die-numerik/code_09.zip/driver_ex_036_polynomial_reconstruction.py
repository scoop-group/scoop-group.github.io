'''
Script that compares the rounding errors of the three different polynomial bases (Monomial, Lagrange, Newton)
'''
import sys
import os
import numpy as np
import matplotlib.pyplot as plt
import interpolators as ips
import linear_solvers as ls
from operator import itemgetter
np.seterr(all='raise')

def zeros_to_coefficients(poly_zeros):
	# Compute polynomial coefficients in monomial basis from prediscribed zeros
	coefficients = np.ones(len(poly_zeros) + 1, dtype = float)
	for i, zero in enumerate(poly_zeros):
		#pdb.set_trace()
		# All current coefficients are promoted by multiplying with x
		coefficients[0:i+2] = np.hstack((np.array([0.0]), coefficients[0:i+1])) 
		# All current coefficients except leading one are combined with previous ones multiplied by zero
		coefficients[0:i+1] -= zero * coefficients[1:i+2] 

# Whether or not to print the interpolations for every shift (warning, if you don't change the number of shifts examined, this will fail because too many figures are opened)
print_interpols = True
print_interpols = not print_interpols

# Set output filestream name
output_filename = os.path.splitext(os.path.basename(__file__))[0] + '_output.txt'

# Set solver for Vandermonde systems
#solve_linear = np.linalg.solve %for some reason throughs a singular matrix error
solve_linear = lambda A,b: ls.LRSolver(A).solve(b)

# Define the polynomial examples
examples = []

###### Define the polynomial in example 1 directly through coefficients 
# Prescribe degree
degree = 5

# Set initial interval
interval = (0.1,1.1)

# Fix maximum shift, this essentially determines the condition of the Vandermonde matrix
max_shift = 600
	
# Discretize shifting up to max_shift
shift_steps = 599
shifts = np.linspace(0, max_shift, shift_steps)

examples.append(
	{
		'name': "prescribed_monomial",
		'coefficients': 1.1 * np.ones(degree + 1, dtype = float),
		'interval': interval,
		'poly': lambda t: ips.poly_eval_horner(coefficients, t),
		'shifts': shifts
	}
	)
	
###### Define the polynomial in example 2 thorugh its zeros as p(x) = (x-z1)(x-z2)...
# Set zeros
#poly_zeros = np.array([290, 300, 310], dtype = float) # if the other problem does not work, try this one. There is some inconsistency in numpy versions and older version may thourgh a singular matrix error
poly_zeros = np.array([290, 295, 300, 305, 310], dtype = float)

# Extract degree
degree = len(poly_zeros)

# Compute coefficients
coefficients = zeros_to_coefficients(poly_zeros)

# Set initial interval
interval = (0,1)

# Fix maximum shift, this essentially determines the condition of the Vandermonde matrix
max_shift = 600
	
# Discretize shifting up to max_shift
shift_steps = 2*max_shift-1
shifts = np.linspace(0, max_shift, shift_steps)

examples.append(
	{
		'name': "prescribed_zeros",
		'coefficients': 1.1 * np.ones(degree + 1, dtype = float),
		'interval': interval,
		# Don't make this evaluation in monomial basis because this introduces errors into corresponding comparative polynomial
		'poly': np.vectorize(lambda t: np.product(t-poly_zeros)),
		'shifts': shifts
	}
	)

# Open output filestream
with open(output_filename, 'w') as filestream:
	print(">>>>>>>>>>>>>>>>>>>>>> Making monomial interpolator perform badly <<<<<<<<<<<<<<<<<<<<<<<", file=filestream)

	for example in examples:
		# Extract data from example
		exname, coefficients, interval, poly, shifts = itemgetter('name', 'coefficients', 'interval', 'poly', 'shifts')(example)
		
		# Get equidistant supports to interpolate for polynomial reconstruction
		supports = np.linspace(*interval, len(coefficients -1))

		# Select the interpolators to be compared
		interpolators = [ips.MonomialInterpolator, ips.LagrangeInterpolator, ips.NewtonInterpolator]

		# Make containers for saved data
		max_rel_eval_errors=[[] for interpolator in interpolators]
		rel_coeff_errors = [[] for coefficient in coefficients]
		vandermonde_condition_numbers = []

		# Iterate over shifts
		for shift in shifts:
			print("\n>>>>>>>>>> Working on shift = {: 1.3f}\n".format(shift), file = filestream)
			
			# Shift the interval and the supports
			shifted_interval = tuple(x + shift for x in interval)
			shifted_supports = np.array([x + shift for x in supports])
			
			# Save the condition number of the Vandermonde matrix of the monomial basis problem
			vandermonde_condition_numbers.append(np.linalg.cond(np.vander(shifted_supports, increasing = True)))
			
			# Set the plot interval. It is extended by a relative factor of alpha for visibility at the end points of the interval of interest. Warning, this influences the maximum relative error because the error is extrapolating in this case. If the intervals are not plotted, maybe leave alpha at 0
			alpha = 0.
			plot_interval = tuple(x - (np.diff(shifted_interval)[0])*((-1)**i)*alpha for i, x in enumerate(shifted_interval))
			
			# Evaluate polynomial at supports to obtain data for reconstruction
			data = poly(shifted_supports)
			
			# Make supports in the plot interval to evaluate error on
			plot_supports = np.linspace(*plot_interval, 150)
			
			# Evaluate polynomial at plot supports to obtain data for plotting
			plot_data = poly(plot_supports)
			
			if print_interpols:
				# Plot polynomials and scatter data on shifted interval
				shifted_figure = plt.figure()
				plt.scatter(shifted_supports, data)
				plt.plot(plot_supports, plot_data)
				plt.xlabel("t")
				plt.ylabel("p(t)")

			# Loop through all interpolating methods
			for i, _interpolator in enumerate(interpolators):
				print("Applying {}".format(_interpolator.__name__), file = filestream)

				# Make interpolator
				if _interpolator == ips.MonomialInterpolator:
					interpolator = _interpolator(shifted_supports, data, solve_linear)
				else:
					interpolator = _interpolator(shifted_supports, data)
				
				# If monomial interpolator is used, compare the coefficients obtained to the prediscribed ones
				if _interpolator == ips.MonomialInterpolator:
					for coeff_nr in range(len(coefficients)):
						try:
							rel_coeff_error = np.abs(interpolator.coefficients[coeff_nr] - coefficients[coeff_nr])/np.abs(coefficients[coeff_nr]) 
							rel_coeff_errors[coeff_nr].append(rel_coeff_error)
						except Exception as e:
							rel_coeff_errors[coeff_nr].append(-1)
				
				# Evaluate the interpolated polynomial at the plot supports
				plot_data_reconstructed = interpolator.evaluate(plot_supports)
				
				# Compute errors in evaluations across the plot data
				try:
					abs_error = np.abs(plot_data - plot_data_reconstructed)
					rel_error = abs_error / np.abs(plot_data)
					max_error = np.max(abs_error)
					max_rel_error = np.max(rel_error)
					max_rel_eval_errors[i].append(max_rel_error)
				except Exception as e:
					max_rel_eval_errors[i].append(-1)
				
				# Print the resulting interpolation if asked to for the current shift
				if print_interpols:
					plt.figure(shifted_figure.number)
					plt.plot(plot_supports, plot_data_reconstructed)

			# Add some info to the plot of the interpolation for the current shift
			if print_interpols:
				plt.figure(shifted_figure.number)
				plt.title('Exact polynomial and interpolations for shift = {: 1.3f}'.format(shift))
				plt.legend(['inputPolynomial'] + [interpolator.__name__ for interpolator in interpolators] + ['data'])

		# Dump info
		print("\nFinished interpolation. Plotting nonzero errors", file = filestream)
		
		# Start plotting -- plot errors in evaluations
		fig, ax = plt.subplots(1,1)
		legend_names = []
		for i, interpolator in enumerate(interpolators):
			nonzero_errors = np.array(max_rel_eval_errors[i]) > 0
			if np.any(nonzero_errors):
				ax.plot(np.array(shifts)[nonzero_errors], np.array(max_rel_eval_errors[i])[nonzero_errors])
				ax.set_yscale('log')
				legend_names.append(interpolator.__name__)
			else:
				print("No nonzero errors for {}".format(interpolator.__name__), file = filestream)
		plt.title('Max. rel. error of interp. and input polynomial')
		plt.xlabel("Shift")
		plt.ylabel("Maximum relative error")
		plt.legend(legend_names)
		plt.savefig('../figures/036_{}_eval_error.png'.format(exname))
		
		# Plot errors in coefficients
		fig, ax = plt.subplots(1,1)
		legend_names = []
		for i, rel_coefficient_error in enumerate(rel_coeff_errors):
			nonzero_errors = np.array(rel_coefficient_error) > 0
			if np.any(nonzero_errors):
				ax.plot(np.array(shifts)[nonzero_errors], np.array(rel_coefficient_error)[nonzero_errors])
				ax.set_yscale('log')
				legend_names.append('Coeff_{: d}'.format(i))
			else:
				print("No nonzero errors in coefficient {: d} for {}".format(i, interpolator.__name__), file = filestream)
		plt.title('Rel. error in coefficients for monomial basis')
		plt.xlabel("Shift")
		plt.ylabel("Maximum relative error")
		plt.legend(legend_names)
		plt.savefig('../figures/036_{}_coeff_error.png'.format(exname))

		# Plot vandermonde condition numbers
		fig, ax = plt.subplots(1,1)
		nonzero_errors = np.array(vandermonde_condition_numbers) > 0
		ax.plot(np.array(shifts)[nonzero_errors], np.array(vandermonde_condition_numbers)[nonzero_errors])
		ax.set_yscale('log')

		plt.title('Condition number of Vandermonde matrices')
		plt.xlabel("Shift")
		plt.ylabel("Condition number")
		plt.savefig('../figures/036_{}_vandermonde_condition.png'.format(exname))
