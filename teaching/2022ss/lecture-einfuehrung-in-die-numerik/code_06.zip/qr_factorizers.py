import numpy as np
import warnings
#import pdb

# Generic qr factorizer super class
class QR_factorizer():
	# Create factorizer
	def __init__(self, _A):
		self.A = _A.copy()
		self.factorized = False
		
		return None
	
	def get_factorized(self):
		return self.factorized

	def factorize():
		pass
	
	def get_Q():
		pass
	
	def get_R():
		pass
	
	def apply_Q(self, B):
		pass
	
	def apply_QT(self, B):
		pass

# numpy QR factorization wrapped as test
class Numpy_QR(QR_factorizer):
	def __init__(self, _A):
		super().__init__(_A)
		return None
	
	def factorize(self):
		if not self.factorized:
			self.Q, self.R = np.linalg.qr(self.A)
			self.factorized = True
	
	def get_Q(self):
		if not self.factorized:
			self.factorize()
		return self.Q
	
	def get_R(self):
		if not self.factorized:
			self.factorize()
		return self.R
	
	def apply_Q(self,B):
		if not self.factorized:
			self.factorize()
		return self.Q@B
	
	def apply_QT(self,B):
		if not self.factorized:
			self.factorize()
		return self.Q.T@B
	
def apply_householder(v, A):
	''' 
		Apply householder matrix Q = I - 2 vv^T/norm(v)^2 to Matrix A.
		Default behavior for v=0 is no reflection
	'''
	
	if not np.all(v==0):
		if len(A.shape) < 2:
			A -= (2 * np.dot(v, A) / np.dot(v, v)) * v
		else:
			for col in range(A.shape[1]):
				A[:,col] -= (2 * np.dot(v, A[:,col]) / np.dot(v, v))  * v
	return A
	
class Householder_QR(QR_factorizer):
	def __init__(self, _A):
		super().__init__(_A)
		self.m, self.n = _A.shape
		if self.m < self.n:
			exit("Input matrix is not rectangular or skinny. Functionality not implemented. Exiting.")
		self.V = []
		return None
	
	def factorize(self):
		if not self.factorized:
			self.R = self.A # shallow copy, no additional memory
			for step in range(self.n):
				# make householder vector
				a = self.R[step:,step]
				v = a.copy() # deep copy
				if a[0] > 0:
					v[0] += np.linalg.norm(a)
				else:
					v[0] -= np.linalg.norm(a)
				
				# remember householder vector
				self.V.append(v)
				
				apply_householder(v, self.R[step:,step:])
			
			self.factorized = True
		return None
	
	def get_Q(self):
		if not self.factorized:
			self.factorize()
		return self.apply_Q(np.eye(self.n))
	
	def get_R(self):
		if not self.factorized:
			self.factorize()
		return self.R[:self.n,:]
	
	def apply_Q(self,_B):
		B = np.vstack((_B.copy(), np.zeros((self.m-self.n,self.n), dtype = float)))
		if not self.factorized:
			self.factorize()
		for step in range(self.n-1,-1,-1):
			apply_householder(self.V[step], B[step:,step:])
		return B
	
	def apply_QT(self,_B):
		B = _B.copy()
		if not self.factorized:
			self.factorize()
		for step in range(self.n):
			apply_householder(self.V[step], B[step:,:])
		return B[:self.n,:]
	
class Gram_Schmidt_QR(QR_factorizer):
	def __init__(self, _A):
		super().__init__(_A)
		self.m, self.n = _A.shape
		if self.m < self.n:
			exit("Input matrix is not rectangular or skinny. Functionality not implemented. Exiting.")
		return None
	
	def factorize(self):
		if not self.factorized:
			#Initialize
			Q = self.A #shallow copy for in place computations
			A = self.A #shallow copy for in place computations
			R = np.zeros((self.n, self.n), dtype = float)

			# Orthogonalize
			for k in range(self.n):
				for l in range(k):
					R[l,k] = np.dot(A[:,k], Q[:,l])
				for l in range(k):
					Q[:,k] -= R[l,k] * Q[:,l]
				R[k,k] = np.linalg.norm(Q[:,k])
				Q[:,k] /= R[k,k]
				
			# Save
			self.Q = Q
			self.R = R
			self.factorized = True
	
	def get_Q(self):
		if not self.factorized:
			self.factorize()
		return self.Q
	
	def get_R(self):
		if not self.factorized:
			self.factorize()
		return self.R
	
	def apply_Q(self,B):
		if not self.factorized:
			self.factorize()
		return self.Q@B
	
	def apply_QT(self,B):
		if not self.factorized:
			self.factorize()
		return self.Q.T@B

class Mod_Gram_Schmidt_QR(QR_factorizer):
	def __init__(self, _A):
		super().__init__(_A)
		self.m, self.n = _A.shape
		if self.m < self.n:
			exit("Input matrix is not rectangular or skinny. Functionality not implemented. Exiting.")
		return None
	
	def factorize(self):
		if not self.factorized:
			#Initialize
			Q = self.A #shallow copy for in place computations
			R = np.zeros((self.n, self.n), dtype = float)
			
			# Orthogonalize
			for k in range(self.n):
				R[k,k] = np.linalg.norm(Q[:,k])
				Q[:,k] /= R[k,k]
				for l in range(k+1,self.n):
					R[k,l] = np.dot(Q[:,k], Q[:,l])
					Q[:,l] -= R[k,l] * Q[:,k]
				
			# Save
			self.Q = Q
			self.R = R
			self.factorized = True
	
	def get_Q(self):
		if not self.factorized:
			self.factorize()
		return self.Q
	
	def get_R(self):
		if not self.factorized:
			self.factorize()
		return self.R
	
	def apply_Q(self,B):
		if not self.factorized:
			self.factorize()
		return self.Q@B
	
	def apply_QT(self,B):
		if not self.factorized:
			self.factorize()
		return self.Q.T@B
