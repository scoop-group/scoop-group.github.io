import numpy as np
import linear_solvers as ls
from operator import itemgetter

def generate_random_testmatrix(upper, dim, nr_of_bad_pivots_per_row, rng):
	''' generate matrix with random numbers and set a given number of elements per row to 1 randomly as bad pivots'''
	# Get matrix
	#A = rng.integers(-upper, upper, size=(dim, dim)).astype("float")
	A = upper*(rng.random(size=(dim, dim))-0.5)
	
	# Set some random indices in the matrix to 1, work rowwise
	if nr_of_bad_pivots_per_row > 0:
		for row in range(dim):
			indices = rng.integers(0,dim,size=(nr_of_bad_pivots_per_row,))
			A[row, indices] = 1
	return A

def check_script_examples(pivots, fs):
	'''Check LR implementation on linear systems in script'''
	# Set examples
	examples = [
		{
			'name': 
				"Example 1 from script (no pivoting needed)",
			'A':
				np.array([
						[ 6, 1,  1],
						[ 3, 3,  1],
						[-6, -6, -3]], dtype=float),
			'b':
				np.array([
					11, 
					5, 
					-9], dtype=float),
			'exact_sol':
				np.array([ 
					2,  
					0,
					-1], dtype=float)
		}# anonymous dictionary
		,
		{
			'name': 
				"Example 2 from script (needs pivoting)",
			'A':
				np.array([
						[0, 1, 1],
						[2, 1, 3],
						[3, 1, 6]], dtype=float),
			'b':
				np.array([
					4, 
					7, 
					2], dtype=float),
			'exact_sol':
				np.array([ 
					4.75,  
					7.25,
					-3.25], dtype=float)
		}# anonymous dictionary
	]# list
	
	# Loop over examples
	for example in examples:
		# Reconstruct example data
		name, A, b, exact_sol = itemgetter('name','A','b','exact_sol')(example)

		# Construct multiple right hand sides for testing
		B = np.hstack((np.atleast_2d(b).transpose(), np.atleast_2d(2*b).transpose()))
		
		# Construct multiple solutions for testing
		exact_sols = np.hstack((np.atleast_2d(exact_sol).transpose(), np.atleast_2d(2*exact_sol).transpose()))
		
		# Dump example info
		print("\n>>>>>>>>>>\n>>>>>>>>>> Testing LR solver decomp for {}\n>>>>>>>>>>".format(name), file=fs)
		print("Input data:\nA = \n", A, "\nb = \n", b, "\nB = \n", B, file=fs)
		
		# Check all pivots
		for pivot in pivots:
			print('\n>>>>>>>>>> Testing pivoting rule "{}"'.format(pivot.__name__), file=fs)
			
			# Instantiate solver without pivoting and factorize
			lrs = ls.LRSolver(A, pivot)
			try:
				# factorize
				lrs.factorize()
				
				# Dump factorization data
				L, R, P, QT = lrs.getLRPQT()
				print("Factorized data:\nL = \n", L, "\nR = \n", R, "\nP = \n", P, "\nQT = \n", QT, file=fs)
				
				# Check relative error of matrix reconstruction
				print("Relative Frobenius-norm-error of             LR to PAQT: {:1.3e}".format(
					np.linalg.norm(L@R-P@A@QT)/np.linalg.norm(P@A@QT)), file=fs)

				# solve single rhs and dump information
				solb = lrs.solve(b)
				#print("Solution of Ax = b:\n", solb, file=fs)
				print("Relative 2-norm-error of            single rhs solution: {:1.3e}".format(
					np.linalg.norm(exact_sol-solb)/np.linalg.norm(exact_sol)), file=fs)

				# solve multiple rhs and dump information
				solB = lrs.solve(B)
				#print("Solution of Ax = B:\n", solB, file=fs)
				print("Relative Frobenius-norm-error of multiple rhs solutions: {:1.3e}".format(
					np.linalg.norm(exact_sols-solB)/np.linalg.norm(exact_sols)), file=fs)
			except Exception as e:
				print('Trying to factorize with pivoting rule "{}" throws Error: "{}"'.format(pivot.__name__, str(e)), file=fs)

def check_random_examples(pivots, fs):
	# Set parameters
	dim_bound = 10
	upper_element_bound = 1e2
	samples = range(50)

	# Get random number generator
	rng = np.random.default_rng(seed = 10)
	
	rel_errors = []
	for pivot in pivots:
		for sample in samples:
			# Get random dimension of problem
			dim = rng.integers(3, dim_bound)

			# Dump some output
			print("\n>>>>>>>>>> Sample {: d} - Solving a(n) {: d}-dimensional problem".format(sample, dim), file = fs)
			
			# Generate a random A of integers
			A = generate_random_testmatrix(upper_element_bound, dim, nr_of_bad_pivots_per_row=0, rng = rng)

			# Fix solution
			x = np.ones(dim, dtype = float)
			
			# Generate right hand side to fixed solution
			b = A @ x
			
			try:
				# Instantiate solver without pivoting and factorize
				lrs = ls.LRSolver(A, pivot)
				
				# Factorize
				lrs.factorize()
				
				# Solve
				sol = lrs.solve(b)
				
				# Get rel error
				rel_error = np.linalg.norm(x-sol)/np.linalg.norm(x)
				
				# Print info
				print("Relative 2-norm-error of solution using {}: {: 1.3e}".format(pivot.__name__,
					rel_error), file=fs)
				
			except Exception as e:
				print('Trying to factorize with pivoting rule "{}" throws Error: "{}"'.format(pivot.__name__, str(e)), file=fs)
				rel_error = -1.0
			
			# remember results
			rel_errors.append(rel_error)
			
	print('\nMaximum relative error in solution of all examples is {: 1.3e}'.format(np.max(rel_errors)), file=fs)
	print('Median  relative error in solution of all examples is {: 1.3e}'.format(np.median(rel_errors)), file=fs)
	
def check_error_amplification(pivots, fs):
	'''Check the behavior LR decomp with different pivots for a badly behaved 2x2 example'''
	
	# Matrix has a small number as first entry, which we loop over. Set bases and exponents for this entry.
	bases = [2, 10]
	exponents = [range(-52, -56, -1), range(-10, -19, -1)]
	
	names = ['first right hand side in script',
					'second right hand side in script']
	
	right_hand_side_gens = [lambda eps: np.array([1,1], dtype=float),
	                    lambda eps: np.array([eps - 1, 2], dtype=float)]
				
	exact_sol_gens = [lambda eps: np.array([2/(eps + 1), (eps-1)/(eps+1)], dtype=float),
	                  lambda eps: np.array([1, 1], dtype=float)]
								
	for name, right_hand_side_gen, exact_sol_gen in zip(names, right_hand_side_gens, exact_sol_gens):
		print('\n>>>>>>>>>> Checking for ' + name, file=fs)
		# Loop through all given epsilons
		for base, expos in zip(bases, exponents):
			print('\n>>>>>>>>>> Checking for eps with base {:d}'.format(base), file=fs)
			for pivot in pivots:
				print('\n>>>>>>>>>> Factorizing with pivoting rule "{}"'.format(pivot.__name__), file=fs)
				for i in expos:
					eps = base**i
					
					A = np.array([
								[eps, -1],
								[  1,  1]], dtype=float)
					
					b = right_hand_side_gen(eps)
					exact_sol = exact_sol_gen(eps)
					
					# factorize A
					lrs = ls.LRSolver(A,pivot)
					lrs.factorize()
					
					# Get factorization data
					L, R, P, QT = lrs.getLRPQT()

					# Check relative error of matrix reconstruction
					two_base_string = "= {:d}^(-53+{:d}) = {:1.4e}".format(base, i+53, eps) if base == 2 else ""
					labelstring = "\nEps = {:d}^{:d} ".format(base, i) + two_base_string + ": \nRelative Frobenius-norm-error of LR to PAQT is {:1.3e}".format(np.linalg.norm(L@R-P@A@QT)/np.linalg.norm(P@A@QT))
					print(labelstring, file=fs)
					
					# solve a system with known solution
					solb = lrs.solve(b)
					
					# compare error in solution
					print("Relative 2-norm-error of             solution: {:1.3e}".format(np.linalg.norm(exact_sol - solb)/np.linalg.norm(exact_sol)), file=fs)
					print("Computed Solution = ", solb, file=fs)


