# Script that tests the LR factorization on the two 3x3 examples in the script
import sys
import os
import numpy as np
import pivot_functions as pivs
from lr_implementation_tests import check_script_examples
np.seterr(all='raise')

# Set output filestream name
output_filename = os.path.splitext(os.path.basename(__file__))[0] + '_output.txt'

# Open output filestream
filestream = open(output_filename, 'w')
# Set pivot types we want to check
pivots = [pivs.no_pivot]

# Check examples
print(">>>>>>>>>>>>>>>>>>>>>> Testing LR solver on small known systems from script <<<<<<<<<<<<<<<<<<<<<<<", file=filestream)
check_script_examples(pivots, filestream)
filestream.close()
