'''
Script that evaluates bezier curves and draws an "S"
'''
import sys
import os
import numpy as np
import matplotlib.pyplot as plt
from operator import itemgetter
np.seterr(all='raise')

class BezierCurve():
	def __init__(self, _B: np.array):
		self.setup(_B)
		return None
		
	def setup(self, _B: np.array):
		# Set the control points
		self.B = _B
		return None
	
	def evaluate(self, ts):
		# Evaluate curve in parameters t using casteljau algorithm
		
		# Make container for output values to be stored in 
		values = np.empty((B.shape[0],len(ts)), dtype = float)
		
		for i, t in enumerate(ts):
			values[:,i], _ = self.evaluate_single(t)
			
		return values
	
	def evaluate_single(self, t, keep_history = False):
		val = self.B.copy()
		history = []
		
		# Recursion
		for k in range(val.shape[1]-1, -1, -1):
			if keep_history:
				history.append(val[:,:k+1].copy())
			for l in range(k):
				val[:,l] = (1-t)*val[:,l] + t*val[:,l+1]
		
		return val[:,0], history

#-------------------------  Example 1 - Work on the example from script 

# Set control points for example in script
B = np.array([[0, 1/3, 2/3, 1], 
							[0, -1,  -1, 1]], dtype = float)

# Initialize Bezier curve
bc = BezierCurve(B)

# Discretize curve parameter space
t = np.linspace(0, 1, 200)

# Evaluate curve along parameter discretization
Bt = bc.evaluate(t)

# Choose some parameters to plot recursion data for
ts = [0.3, 0.4, 0.5, 0.6, 0.7]
for t in ts:
	
	# Open new figure
	plt.figure()
	
	# Plot curve
	plt.plot(Bt[0,:], Bt[1,:], color = 'red')

	# Scatter control points
	plt.scatter(B[0,:], B[1,:], color = 'black')

	# Draw connections between control points
	for k in range(B.shape[1]-1):
		plt.plot(B[0,k:k+2], B[1,k:k+2], color = 'black') 
	plt.plot([B[0,-1], B[0,0]], [B[1,-1], B[1,0]], color = 'black') 

	# Annotate control points	
	for k in range(B.shape[1]):
		plt.annotate(r"$b_{:d}$".format(k), B[:,k] - np.array([0, 0.1]))

	# Evaluate for single control point and remember the recursion data to plot
	b, history = bc.evaluate_single(t, keep_history = True)

	# Scatter final evaluation
	plt.scatter(*b, color = 'red')

	# Draw historic evaluation data
	colors = plt.rcParams['axes.prop_cycle'].by_key()['color']
	for clr, hist in zip(colors, history[1:-1]):
		# Scatter intermediate control points
		plt.scatter(hist[0,:], hist[1,:], color = clr) 
		for k in range(hist.shape[1]-1):
			# Plot intermediate control points
			plt.plot(hist[0,k:k+2], hist[1,k:k+2], color = clr) 

	# Save plot to png
	plt.title('Bezier curve script example, construction for t = {: 1.2f}'.format(t))
	plt.savefig('../figures/040_bezier_curve_script_{:1.1f}.png'.format(t))
	
#-------------------------  Example 2 - Draw letter S

# Set control points for letter "S"
B = np.array([[-1, 5, -5, 1], 
							[0, 0,  1, 1]], dtype = float)

# Initialize Bezier curve
bc = BezierCurve(B)

# Discretize curve parameter space
t = np.linspace(0, 1, 200)

# Evaluate curve along parameter discretization
Bt = bc.evaluate(t)

# Open new figure
plt.figure()

# Plot curve
plt.plot(Bt[0,:], Bt[1,:], color = 'red')

# Scatter control points
plt.scatter(B[0,:], B[1,:], color = 'black')

# Draw connections between control points
for k in range(B.shape[1]-1):
	plt.plot(B[0,k:k+2], B[1,k:k+2], color = 'black') 

# Annotate control points
for k in range(B.shape[1]):
	plt.annotate(r"$b_{:d}$".format(k), B[:,k] - np.array([0, 0.1]))
	
# Save plot to png
plt.title('Bezier curve for letter \"S\"')
plt.savefig('../figures/040_bezier_curve_letter_s.png'.format(t))	

plt.xlim([-1.5,1.5])
plt.ylim([-0.1,1.1])
plt.savefig('../figures/040_bezier_curve_letter_s_zoomed.png'.format(t))	

#plt.show()
