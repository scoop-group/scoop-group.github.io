# This code demonstrates the fact that the singular
# value decomposition of a matrix yields the solutions
# to the best-fixed-rank approximation problem to a given 
# matrix, where 'best' means smallest in terms of the
# 2->2 matrix norm..

# Resolve the dependencies.
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as image

# Read the image.
A = image.imread('cameraman.png')

# Scale the image to [0,1] (not needed for pngs according to documentation)
A = (A - A.min()) / (A.max() - A.min())

# Perform the SVD.
U, Sigma, VT = np.linalg.svd(A)

# Get rank of A
fullrank = np.count_nonzero(Sigma)

# Create the figure.
fig, ax = plt.subplots(2, 2)

# Show the original image.
plt.sca(ax[0][0])
plt.imshow(A, cmap = 'gray')
plt.axis('off')
plt.title('original image')

# Loop over selected ranks
ranks = [0,1,2,3,4,15,50,100,200,Sigma.shape[0]]
for iter in ranks:

  # Show the singular values and highlight the current position.
  plt.sca(ax[0][1])
  plt.cla()
  plt.semilogy(Sigma, 'k-')
  if iter>0:
    plt.semilogy(iter,Sigma[iter-1], 'ro')
  plt.title('singular values')

  # Show the reconstructed image.
  Ahat = U[:,:iter] * Sigma[:iter] @ VT[:iter,:]
  fraction = sum(Sigma[:iter]) / sum(Sigma)
  plt.sca(ax[1][0])
  plt.imshow(Ahat, cmap = 'gray')
  plt.clim([0.0, 1.0])
  plt.axis('off')
  plt.title('rank = {rank:3d}/{fullrank:3d} fraction = {fraction:5.2f} %'.format(rank = iter, fullrank = fullrank, fraction = 100 * fraction))

  # Show the approximation error.
  plt.sca(ax[1][1])
  cax = plt.imshow(A - Ahat, cmap = 'seismic')
  plt.clim([-0.5, 0.5])
  plt.axis('off')
  plt.title('approximation error')
  
  # Set larger size for printing
  plt.gcf().set_size_inches(12, 9)
  
  # Save figure
  plt.savefig('../figures/cameraman_approximation_behavior_rank_{rank:03d}.png'.format(rank=iter), bbox_inches='tight')
  
  # Print image to png to see size
  plt.imsave("../figures/cameraman_approximation_rank_{rank:03d}.png".format(rank=iter),Ahat, cmap = 'gray',format='png')
  
#plt.show()

