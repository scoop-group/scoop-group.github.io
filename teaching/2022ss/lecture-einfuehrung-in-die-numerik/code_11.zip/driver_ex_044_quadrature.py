'''
Script that uses summed trapezoidal rule as quadrature for sin function and visualizes convergence rate
'''
import sys
import os
import numpy as np
import matplotlib.pyplot as plt
from operator import itemgetter

np.seterr(all='raise')

def sum_trap(interval, f, n):
	'''Evaluate summed trapezoidal rule for n subintervals to approximate int_interval f '''
	
	fun_vals = f(np.linspace(*interval, n+1))
	weights = np.diff(interval)/n * np.concatenate(([0.5],np.ones((n-1), dtype = float),[0.5]))
	
	return np.inner(weights,fun_vals)

# Set output filestream name
output_filename = os.path.splitext(os.path.basename(__file__))[0] + '_output.txt'

# Set examples to compute
examples = [
	{
		'name': 'Sin',
		'function': np.sin,
		'error_ref_name': 'pi/12 h^2',
		'error_ref': lambda n: np.pi**3/12/(n**2),
		'interval': (0,np.pi),
		'exact_int': 2
	},
	{
		'name': 'Indicator',
		'function': lambda x: np.where(x<1,1,0),
		'error_ref_name': '1/10 h',
		'error_ref': lambda n: np.pi/10 * 1/n,
		'interval': (0,np.pi),
		'exact_int': 1
	}
]

# Create empty containers
values = [[] for example in examples]
rel_errors = [[] for example in examples]

nrange = 2**np.arange(1,15)

# Open output filestream
with open(output_filename, 'w') as filestream:
	print('>>>>>>>>>>>>>>>>>>>>>> Comparing quadrature to exact integral value for given examples <<<<<<<<<<<<<<<<<<<<<<<', file=filestream)

	for i, example in enumerate(examples):
		exname, function, interval, exact_int = itemgetter('name', 'function', 'interval', 'exact_int')(example)

		# Dump info
		print('\n>>>> Working on function "{:>10}" on interval [{: 1.2e},{: 1.2e}]'.format(exname, *interval), file=filestream)
		
		print('{:^7}|{:^13}|{:^13}'.format('n', 'value', 'rel_error'), file=filestream)
		print('------------------------------------', file=filestream)

		for n in nrange:
			# Compute quadrature an relative error
			approx_int = sum_trap(interval, function, n)
			rel_error = np.abs((approx_int - exact_int)/exact_int)
			
			# Remember values
			values[i].append(approx_int)
			rel_errors[i].append(rel_error)
			
			print('{: >6d} | {: 1.4e} | {: 1.4e}'.format(n, approx_int, rel_error), file=filestream)
			
	print("\nFinished computing quadratures. Plotting nonzero errors", file = filestream)
	
	# Get colors for drawing
	colors = plt.rcParams['axes.prop_cycle'].by_key()['color']
	
	# Open figure an make container
	fig, ax = plt.subplots(1,1)
	plot_names = []
	
	for i, (example, clr) in enumerate(zip(examples, colors)):
		# Get nonzero relative errors for plotting
		nonzero_errors = np.array(rel_errors[i]) > 0
		
		# Plot
		if np.any(nonzero_errors):
			ax.plot(nrange, np.array(rel_errors[i], dtype = float)[nonzero_errors], color = clr)	
			
			plot_names.append(itemgetter('name')(example))

			try:
				ax.plot(nrange, example['error_ref'](nrange), color = clr, linestyle = 'dashed')
				plot_names.append(example['error_ref_name'])
			except Exception as e:
				print("No specified reference error for {} found.".format(example['name']), file = filestream)
				
		else:
			print("No nonzero errors for {}".format(example['name']), file = filestream)
	
	ax.set_yscale('log')
	ax.set_xscale('log')
			
	plt.title('Rel. error of summed trapezoidal rule')
	plt.xlabel("Number n of intervals")
	plt.ylabel("Relative error")
	plt.legend(plot_names)
	plt.savefig('../figures/044_trapezoidal_convergence.png'.format(exname))
