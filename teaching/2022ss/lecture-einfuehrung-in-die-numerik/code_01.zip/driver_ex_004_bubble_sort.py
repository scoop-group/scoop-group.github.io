# This script visualizes bubble sort complexity for random instances of number lists of given max length
import numpy as np
import matplotlib.pyplot as plt

def bubble_sort(a):
	"""
	Implements "bubble sort" where an array of numbers is sorted by swapping larger numbers to the end of the array.
	Needs n-1 passes through array that need decreasing number of comparisons/swaps
	Accepts:
		       a: list of numbers
	Returns: 
		       sorted list of numbers
	"""
	
	# Obtain number of elements to sort
	n = len(a)
	
	# Define trackers for comparisons and swaps
	comps, swaps = 0,0
	
	# Loop over all passes through numbers
	for i in range(n-1):
		# Loop over all objects in array subsection except last (because we compare forward
		for j in range(n-1-i):
			comps +=1
			if a[j] > a[j+1]:
				swaps +=1
				a[j],a[j+1] = a[j+1],a[j]
	
	return a,comps,swaps

# Create pseudo random number generator
rng = np.random.default_rng(seed = 10)

#Set pseudo random data parameters
number_of_samples = 1000
max_random_entry = 100
min_n = 1
max_n = 100

# Randomly set size of sample
N = rng.integers(min_n,max_n+1,number_of_samples)

# Create data container
sizes = []
comps = []
swaps = []

for n in N:
	# Sort the sample
	_,c,s = bubble_sort(max_random_entry * rng.random(n))
	# Save the data
	sizes.append(n)
	comps.append(c)
	swaps.append(s)

# Compute best and worst case references
ref_size = np.array(range(max_n+1))
worst_case = np.multiply(ref_size,ref_size-1)*0.5

## Print the results
#for n,c,s in zip(sizes,comps,swaps):
	#print(n,c,s)
	
# Plot the results
fig, ax = plt.subplots(figsize = (8,8))
# Set logarithmic scale on the y variable
#ax.set_yscale("log");
#ax.set_xscale("log");
ax.plot(worst_case)
#ax.plot(ref_size)
ax.scatter(sizes, comps, s=60, alpha=0.7, edgecolors="k")
ax.scatter(sizes, swaps, s=60, alpha=0.7, edgecolors="k")

plt.title('Bubble sort asymptotics')
plt.legend(['Worst case','Comparisons', 'Swaps'])
plt.xlabel('Number of elements to sort')
plt.ylabel('Number of actions')

plt.savefig('../figures/bubble_sort_asymptotics.png')
