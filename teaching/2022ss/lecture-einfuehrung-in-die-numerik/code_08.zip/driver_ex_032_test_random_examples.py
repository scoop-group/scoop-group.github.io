# Script that tests the LR factorization on the two 3x3 examples in the script
import sys
import os
import numpy as np
import qr_factorizers as qrs
import linear_solvers as ls
from lr_implementation_tests import generate_random_testmatrix
np.seterr(all='raise')

# Set output filestream name
output_filename = os.path.splitext(os.path.basename(__file__))[0] + '_output.txt'

factorizers = [qrs.Numpy_QR, qrs.Householder_QR, qrs.Gram_Schmidt_QR, qrs.Mod_Gram_Schmidt_QR]

# Open output filestream
with open(output_filename, 'w') as filestream:
	print(">>>>>>>>>>>>>>>>>>>>>> Testing QR solver for random matrices <<<<<<<<<<<<<<<<<<<<<<<", file=filestream)
	
# Set parameters
	dim_bound = 10
	upper_element_bound = 1e2
	samples = range(50)

	# Get random number generator
	rng = np.random.default_rng(seed = 10)
	
	rel_error_orts = []
	rel_error_sols = []
	rel_error_facs = []
	for factorizer in factorizers:
		for sample in samples:
			# Get random dimension of problem
			dim = rng.integers(3, dim_bound)

			# Dump some output
			print("\n>>>>>>>>>> Sample {: d} for {:} - Solving a(n) {: d}-dimensional problem".format(sample, factorizer.__name__,  dim), file = filestream)
			
			# Generate a random A of integers
			A = generate_random_testmatrix(upper_element_bound, dim, nr_of_bad_pivots_per_row=0, rng = rng)

			# Fix solution
			x = np.ones(dim, dtype = float)
			
			# Generate right hand side to fixed solution
			b = A @ x
			
			try:
				# Instantiate solver
				qrs = ls.QRSolver(A, factorizer)

				# Solve
				sol = qrs.solve(b)
				
				Q, R = qrs.get_QR()
				
				# Get rel errors
				rel_error_ort = np.linalg.norm(Q@Q.T - np.eye(dim))/np.linalg.norm(np.eye(dim))
				rel_error_fac = np.linalg.norm(Q@R - A)/np.linalg.norm(A)
				rel_error_sol = np.linalg.norm(x - sol)/np.linalg.norm(x)
				
				## Print info
				print("Relative 2-norm-error of Q-orthogonality using {}: {: 1.3e}".format(factorizer.__name__,
					rel_error_ort), file=filestream)
				print("Relative 2-norm-error of   factorization using {}: {: 1.3e}".format(factorizer.__name__,
					rel_error_fac), file=filestream)
				print("Relative 2-norm-error of        solution using {}: {: 1.3e}".format(factorizer.__name__,
					rel_error_sol), file=filestream)
				
			except Exception as e:
				print('Trying to factorize with factorizer "{}" throws Error: "{}"'.format(factorizer.__name__, str(e)), file=filestream)
				rel_error_ort = -1.0
				rel_error_fac = -1.0
				rel_error_sol = -1.0
			
			# remember results
			rel_error_orts.append(rel_error_ort)
			rel_error_facs.append(rel_error_fac)
			rel_error_sols.append(rel_error_sol)

		print('\nMaximum relative error in Q-orthogonality of all examples using {} is {: 1.3e}'.format(factorizer.__name__, np.max(rel_error_orts)), file=filestream)
		print('Median  relative error in solution of all examples using {} is {: 1.3e}'.format(factorizer.__name__, np.median(rel_error_orts)), file=filestream)
			
		print('\nMaximum relative error in factorization of all examples using {} is {: 1.3e}'.format(factorizer.__name__, np.max(rel_error_facs)), file=filestream)
		print('Median  relative error in factorization of all examples using {} is {: 1.3e}'.format(factorizer.__name__, np.median(rel_error_facs)), file=filestream)
		
		print('\nMaximum relative error in solution of all examples using {} is {: 1.3e}'.format(factorizer.__name__, np.max(rel_error_sols)), file=filestream)
		print('Median  relative error in solution of all examples using {} is {: 1.3e}'.format(factorizer.__name__, np.median(rel_error_sols)), file=filestream)
