# Script that compares the relative errors when solving random linear systems of equations using LR factorization for random total pivoting and total pivoting
import numpy as np
import matplotlib.pyplot as plt
import math
from operator import itemgetter

def func(alpha,t):
	f0 = t**3
	f1 = np.pi*math.sin(t**2)
	f2 = math.log(3*t)
	f3 = math.exp(t)
	f4 = 1
	return alpha[0]*f0 + alpha[1]*f1 + alpha[2]*f2 + alpha[3]*f3 + alpha[4]*f4

# Get random number generator
rng = np.random.default_rng(seed = 10)

# Generate data sets
parameter_sets = [
		{
			'alpha': [0,0,0,0,3.1415],
			't0': 2,
			't1': 7,
			'num_supports': 15,
			'max_rel_noise': 0.0,
		},# Set 1
		{
			'alpha': [0,1,2,0,3],
			't0': 0,
			't1': 6,
			'num_supports': 75,
			'max_rel_noise': 0.0,
		},# Set 2
		{
			'alpha': [1.5,4,1,-2,0],
			't0': 1,
			't1': 5,
			'num_supports': 100,
			'max_rel_noise': 0.0,
		},# Set 3
		{
			'alpha': [3.2,0,0,-3.1,0],
			't0': 0,
			't1': 5.7,
			'num_supports': 180,
			'max_rel_noise': 0.0,
		},# Set 4
		{
			'alpha': [-2,1,1,1,0],
			't0': 2,
			't1': 6,
			'num_supports': 70,
			'max_rel_noise': 0.15,
		}# Set 4
	]

names = []
dataloss = False
for set_num, parameter_set in enumerate(parameter_sets):
	# Unpack data
	alpha, t0, t1, num_supports, max_rel_noise = itemgetter('alpha','t0','t1','num_supports','max_rel_noise')(parameter_set)
	
	# Generate random supports (should be made unique, but no conflict for small amount of data points)
	supports = t0 + (t1-t0) * np.sort(rng.random(num_supports))
	
	# Evaluate function
	data = np.vectorize(lambda supp: func(alpha, supp))(supports)
	
	# Add some noise to the data
	data = data * (1.0 + max_rel_noise*(rng.random(num_supports) - 0.5))
	
	# Name dataset
	names.append("dataset_{:d}".format(set_num))
	
	# Save dataset
	np.save("032_" + names[-1] + ".npy", (supports, data))
	np.save("032_" + names[-1] + "_solution.npy", alpha)
	
	# Check whether loaded data coincides with saved data
	x, y = np.load("032_" + names[-1] + ".npy")
	dataloss = dataloss or not (np.all(x == supports) and np.all(y == data))
	
	# Plot Dataset
	plt.scatter(supports, data)
	plotsupports = np.linspace(min(supports),max(supports),500)
	plt.plot(plotsupports, np.vectorize(lambda supp: func(alpha, supp))(plotsupports))

# Dump info
if dataloss:
	print("Warning, saved and loaded data does not coincide")
else:
	print("Saved and loaded data coincides")

# Plot and save plot
plt.title("Datasets")
plt.xlabel("t")
plt.ylabel("f(t)")
plt.legend(names)
plt.savefig('../figures/032_generated_datasets.png')
#plt.show()
