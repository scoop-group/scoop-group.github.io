# Script that tests the LR factorization on the two 3x3 examples in the script
import sys
import os
import numpy as np
from scipy.linalg import hilbert
import qr_factorizers as qrs
import matplotlib.pyplot as plt
np.seterr(all='raise')

# Set output filestream name
output_filename = os.path.splitext(os.path.basename(__file__))[0] + '_output.txt'

factorizers = [qrs.Householder_QR, qrs.Gram_Schmidt_QR, qrs.Mod_Gram_Schmidt_QR]
#factorizers = [qrs.Gram_Schmidt_QR, qrs.Mod_Gram_Schmidt_QR]

dim_max = 50
dims = range(2, dim_max+1)

# Open output filestream
with open(output_filename, 'w') as filestream:
	#print(">>>>>>>>>>>>>>>>>>>>>> Comparing Gram Schmidt Orthogonality <<<<<<<<<<<<<<<<<<<<<<<", file=filestream)
	
	#print(">>>>>>>>>>>>>>>>>>>>>> Comparing on Hilbert matrices <<<<<<<<<<<<<<<<<<<<<<<", file=filestream)
	factorizer_errors = [[] for factorizer in factorizers]
	for n in dims:
		# Make Hilbert Matrix
		H = hilbert(n)
		
		for i, _factorizer in enumerate(factorizers):
			# Factorize using factorizer
			factorizer = _factorizer(H)
			
			# Compute orthogonality errors
			Q = factorizer.get_Q()
			Q_ortho_error = np.linalg.norm(Q.T@Q-np.eye(n))/np.linalg.norm(np.eye(n))
			
			# Save errors in lists
			factorizer_errors[i].append(Q_ortho_error)
			
	# Plot errors
	for factorizer_error in factorizer_errors:
		plt.plot(dims, factorizer_error)
	
	plt.xlabel('Dimension')
	plt.ylabel('Relative orthogonality error')
	plt.title('Relative orthogonality error in Q')
	plt.legend([factorizer.__name__ for factorizer in factorizers])
	plt.savefig('../figures/031_gram_schmidt_orthogonality.png')
	#plt.show()
