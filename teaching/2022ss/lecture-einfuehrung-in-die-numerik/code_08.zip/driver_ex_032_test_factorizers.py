# Script that tests the LR factorization on the two 3x3 examples in the script
import sys
import os
import numpy as np
import qr_factorizers as qrs
import linear_solvers as ls
from operator import itemgetter
np.seterr(all='raise')

# Set output filestream name
output_filename = os.path.splitext(os.path.basename(__file__))[0] + '_output.txt'

#factorizers = [qrs.Householder_QR]
factorizers = [qrs.Numpy_QR, qrs.Householder_QR, qrs.Gram_Schmidt_QR, qrs.Mod_Gram_Schmidt_QR]
#factorizers = [qrs.Numpy_QR, qrs.Householder_QR, qrs.Gram_Schmidt_QR]

# Make example data
q_1 = np.array([[1, -1, 0]], dtype=float)
q_1 /= np.linalg.norm(q_1)
q_2 = np.array([[1, 1, 1]], dtype=float)
q_2 /= np.linalg.norm(q_2)
q_3 = np.array([[1, 1, -2]], dtype=float)
q_3 /= np.linalg.norm(q_3)

examples=[
	{
		'probname': "square problem",
		'Q_ex': np.hstack((q_1.T, q_2.T, q_3.T)),
		'R_ex': np.array([
				[2, -2, -4],
				[0,  3,  5],
				[0,  0, -1]
			], dtype=float)
	},
	{
		'probname': "rectangular problem",
		'Q_ex': np.hstack((q_1.T, q_2.T)),
		'R_ex': np.array([
				[2, -2],
				[0,  3]
			], dtype=float)
	}
	]

# Open output filestream
with open(output_filename, 'w') as filestream:
	print(">>>>>>>>>>>>>>>>>>>>>> Testing QR factorizers <<<<<<<<<<<<<<<<<<<<<<<", file=filestream)
	for _factorizer in factorizers:
		print("\n>>>>>>>>>>>>>>>>>>>>>> Testing {} <<<<<<<<<<<<<<<<<<<<<<<".format(_factorizer.__name__), file=filestream)
		for example in examples:
			# Reconstruct example data
			Q_ex, R_ex, probname = itemgetter('Q_ex','R_ex','probname')(example)
			print("\n>>>>> Running on {}".format(probname), file=filestream)
			
			A_ex = Q_ex@R_ex
			m, n = A_ex.shape
			
			
			# Factorize
			factorizer = _factorizer(A_ex)
			factorizer.factorize()
			
			# Get factorization data
			Q, R = factorizer.get_Q() , factorizer.get_R()
			A = Q@R

			# Compute errors
			rel_error_A = np.linalg.norm(A - A_ex)/np.linalg.norm(A_ex)
			
			# Dump some output
			print("Q_ex = \n", Q_ex, file=filestream)
			print("Q = \n", Q, "\n", file=filestream)
			print("R_ex = \n", R_ex, file=filestream)
			print("R = \n", R, "\n", file=filestream)
			print("A_ex = \n", A_ex, file=filestream)
			print("A = \n", A, file=filestream)

			## Print errors
			print("\nRelative 2-norm-error of A to A_ex using {}: {: 1.3e}".format(_factorizer.__name__,
				rel_error_A), file=filestream)
			print("Relative 2-norm-error of Q-orthogonality using {}: {: 1.3e}".format(_factorizer.__name__,
				np.linalg.norm(Q.T@Q - np.eye(A.shape[1]))/np.linalg.norm(np.eye(A.shape[1]))), file=filestream)
			
			## Print more errors
			print("\nRelative 2-norm-error of Q  - apply_Q(I)  using {}: {: 1.3e}".format(_factorizer.__name__,
				np.linalg.norm(Q - factorizer.apply_Q(np.eye(n)))/np.linalg.norm(Q)), file=filestream)
			print("Relative 2-norm-error of QT - apply_QT(I) using {}: {: 1.3e}".format(_factorizer.__name__,
				np.linalg.norm(Q.T - factorizer.apply_QT(np.eye(m)))/np.linalg.norm(Q.T)), file=filestream)
