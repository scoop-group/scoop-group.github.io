# Script that tests the LR factorization on the two 3x3 examples in the script
import sys
import os
import numpy as np
import math
import qr_factorizers as qrs
import linear_solvers as ls
import matplotlib.pyplot as plt


np.seterr(all='raise')

def comp_func(t):
	f0 = t**3
	f1 = np.pi*math.sin(t**2)
	f2 = math.log(3*t)
	f3 = math.exp(t)
	f4 = 1
	return [f0, f1, f2, f3, f4]

def func(alpha,t):
	return np.inner(alpha,comp_func(t))

# Set output filestream name
output_filename = os.path.splitext(os.path.basename(__file__))[0] + '_output.txt'

# Set factorizer
factorizer = qrs.Householder_QR

# Open output filestream
with open(output_filename, 'w') as filestream:
	print(">>>>>>>>>>>>>>>>>>>>>> Solving linear least squares problems for provided datasets <<<<<<<<<<<<<<<<<<<<<<<", file=filestream)
	datasets = ["dataset_{:d}".format(i) for i in range(5)]
	
	for dataset in datasets:
		print("\n>>>>>>>>>> Working on {}".format(dataset), file = filestream)
		
		# Load Data and solutions
		supports, data = np.load("032_" + dataset + ".npy")
		alpha = np.load("032_" + dataset + "_solution.npy")
		
		# Generate Matrix for least squares problem
		A = np.empty((len(supports), 5))
		for row, support in enumerate(supports):
			A[row,:] = comp_func(support)
		
		# Solve the naive way and report
		# Make QR Solver
		qrs = ls.QRSolver(A.T@A, factorizer)
		sol = qrs.solve(A.T@data)
		
		print("true alpha = \n", alpha, file=filestream)
		print("     alpha = \n", sol, file=filestream)
		
		print("Naive  relative deviation is: {: 1.4e}".format(np.linalg.norm(alpha-sol)/np.linalg.norm(alpha)), file = filestream)
		
		# Solve the direct way and report
		qrs = ls.QRSolver(A, factorizer)
		sol = qrs.solve(data)
		print("Direct relative deviation is: {: 1.4e}".format(np.linalg.norm(alpha-sol)/np.linalg.norm(alpha)), file = filestream)
		
		# Plot results
		plt.scatter(supports, data)
		plotsupports = np.linspace(min(supports),max(supports),500)
		plt.plot(plotsupports, np.vectorize(lambda supp: func(sol, supp))(plotsupports))

# Plot and save plot
plt.title("Datasets")
plt.xlabel("t")
plt.ylabel("f(t)")
plt.legend(datasets)
plt.savefig('../figures/032_solved_datasets.png')
#plt.show()
