# This module implements various plotting functions to visualize the results
# of iterative optimization schemes and more.

import numpy as np

import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

from mpl_toolkits import mplot3d

from scipy.spatial import HalfspaceIntersection
from scipy.spatial import ConvexHull

from itertools import cycle
import pdb

plt.rcParams["figure.figsize"] = (10, 10)

def plot_2d_iterates_contours(f, histories, labels):
	""" 
	Plot 2d iterates provided in histories of iterative solvers in the iterate 
	space with contour lines at the levels of the visited iterate's function values.
  
	Accepts:
		               f: the function that was minimized by the iterative solvers
		       histories: list of history dictionaries created from the iterative solvers
		          labels: list of label strings for the plot

	Returns:
		       No return values.
	"""
	# Determine a quadratic bounding box for the iterates
	all_iterates = np.vstack(list(np.vstack(history["iterates"]) for history in histories))
	max_abs_component = (np.abs(all_iterates).max())
	discretization_points = np.linspace(-1.5*max_abs_component, 1.5*max_abs_component, num = 251)
	X, Y = np.meshgrid(discretization_points, discretization_points)

	# Get the function values of f on the grid for contour plots
	Z = np.zeros((discretization_points.shape[0], discretization_points.shape[0])) 
	for i, x_comp in enumerate(discretization_points):
		for j, y_comp in enumerate(discretization_points):
			Z[i,j] = f(np.array([x_comp,y_comp]), derivatives=[True,False,False])["function"]
	
	fig = plt.figure()
	for history in histories:
		# Plot contour lines at iterate function values levels (max of 20)
		contour_vals = sorted(set(history["objective_values"][20::-1]))
		plt.contour(X, Y, Z.T, levels = np.asarray(contour_vals))
		
		# Plot 2d iterates
		plt.plot(np.vstack(history["iterates"])[:,0], np.vstack(history["iterates"])[:,1], 's-')

	plt.gca().set_aspect('equal','box')
	plt.title('Iterates and iso-lines of function')
	plt.legend(labels)
	plt.xlabel('x')
	plt.ylabel('y')

def plot_f_val_diffs(histories, reference_values, labels, condition_numbers = None):
	"""
	Plot difference of objective function values provided in histories of 
	iterative solvers and user supplied reference values for each history. 
	
	If the user supplied reference values are the optimal value and the
	the problem is quadratic, then this equals the squared energy norm 
	of the error. Otherwise this method may be used to provide approximative 
	information. 
	
	Optional plot is the expected upper bound for convergence
	speed for quadratic problems provided the generalized condition number.
	
	Accepts:
		               histories: list of history dictionaries created from the iterative solvers
		        reference_values: list of reference values
		                  labels: list of label strings for the plot
		       condition_numbers: list of generalized condition numbers if the problems in histories
		                          were quadratic (default None) 

	Returns:
		       No return values.
	"""
  
	# Evaluate and plot the differences of the objective values and reference values
	fig = plt.figure()
	
	for history, reference_value in zip(histories, reference_values):
		history["f_val_diffs"] = history["objective_values"] - reference_value
		plt.semilogy(history["f_val_diffs"])
	
	# If condition_numbers were supplied, assume that f was quadratic and plot
	# upper bounds on convergence speed
	bound_labels = []
	try:
		plt.gca().set_prop_cycle(None) # Restart the color cycle
		
		for history, reference_value, condition_number, label in \
			zip(histories, reference_values, condition_numbers, labels):
			# Evaluate the linear convergence factor from condition quotient  
			condition_quotient = (condition_number - 1) / (condition_number + 1)
			
			# Evaluate initial energy norm of error squared from the function value diffs
			initial_error_2 = history["objective_values"][0] - reference_value
			
			# Evaluate the predicted upper bound at each iteration starting from the initial error norm
			upper_error_2_bound = initial_error_2 * (condition_quotient ** (2*np.arange(0,len(history["objective_values"]))))
			
			plt.semilogy(upper_error_2_bound, '--')
			bound_labels.append(label + " bound")  
			
	except:
		print("No condition numbers plotable.")
		
	plt.title('Difference of functional values')
	plt.xlabel('Iteration')
	plt.ylabel('Functional value difference')
	plt.legend(labels + bound_labels)

def plot_step_sizes(histories,labels):
	"""Plot the step lengths of a list of histories."""
	fig = plt.figure()
	for history in histories:
		plt.plot(history["step_lengths"])
		
	plt.title('Step lengths')
	plt.xlabel('Iteration')
	plt.ylabel('Step length')
	plt.legend(labels)

def plot_grad_norms(histories,labels):
	"""Plot the gradient norms of a list of histories."""
	fig = plt.figure()
	for history in histories:
		plt.semilogy(history["gradient_norms"])
		
	plt.title('Preconditioner norm of gradients')
	plt.xlabel('Iteration')
	plt.ylabel('Norm value')
	plt.legend(labels)

def plot_used_newton_direction(histories,labels):
	"""Plot the boolean whether or not Newton direction was used."""
	fig = plt.figure()
	for history in histories:
		plt.plot(history["used_newton_direction"], '*')
		
	plt.title('Used Newton direction in iteration?')
	plt.xlabel('Iteration')
	plt.ylabel('Newton used')
	plt.legend(labels)
	plt.gca().set_ylim(-0.1,1.1)

def plot_simplex_iterations_over_dimension(results):
	""" Plot the number of simplex iterations over the space dimension n
	for a list of results"""

	# Collect data
	N = np.array([result["n"] for result in results])
	iterations = np.array([result["iterations"] for result in results])

	# Plot
	fig = plt.figure()
	plt.semilogy(N, iterations, '*')

	# Plot analytical exponential function
	x_discretization = np.linspace(min(N), max(N), 150)
	plt.semilogy(x_discretization,np.power(2, x_discretization)-1, '-')
	
	# Set labels
	plt.legend(['iterations',r'$2^n-1$'])
	plt.title('Simplex iterations over n')
	plt.xlabel('n')
	plt.ylabel('Iterations')
	
	
def plot_simplex_iterations_over_sum(results):
	""" Plot the number of simplex iterations over the space dimension n
	for a list of results"""

	# Collect data
	N = np.array([result["n"] for result in results])
	M = np.array([result["m"] for result in results])
	iterations = np.array([result["iterations"] for result in results])

	# Plot
	fig = plt.figure()
	plt.plot(N+M, iterations, '*')

	# Plot analytical exponential function
	
	# Set labels
	plt.title('Simplex iterations over sum of n and m')
	plt.xlabel('n+m')
	plt.ylabel('Iterations')
	
	
def plot_simplex_iterations_over_quotient(results):
	""" Plot the number of simplex iterations over the quotient of the constraint number m
	and problem size n for a list of results"""

	# Collect data
	N = np.array([result["n"] for result in results])
	M = np.array([result["m"] for result in results])
	iterations = np.array([result["iterations"] for result in results])

	# Plot
	fig = plt.figure()
	plt.plot(np.true_divide(M, N), iterations, '*')

	plt.title('Simplex iterations over m/n')
	plt.xlabel('m/n')
	plt.ylabel('Iterations')
	

def plot_klee_minty_iteration_numbers(dimensions, iterations):
	""" Plot the iterations over the dimensions and add a plot for 2^(x)-1"""
	# Plot dimensions
	fig = plt.figure()
	plt.plot(dimensions, iterations, '*')
	
	# Plot analytical exponential function
	x_discretization = np.linspace(min(dimensions), max(dimensions), 150)
	plt.plot(x_discretization,np.power(2, x_discretization)-1, '-')
	
	# Set labels
	plt.title('Simplex iterations for the Klee-Minty problem')
	plt.xlabel('Cube dimension n')
	plt.ylabel('Iterations')
	plt.legend(['iterations',r'$2^n-1$'])

def plot_polyhedron(A, b, center):
	""" Plot a 2/3-D polyhedron defined by Ax<=b
	Accepts: 
		            A: The matrix that stores the halfspace normals row-wise
		            b: The corresponding half space values
		       center: A point in the interior of the polyhedron (needed for computing intersections - can be computed using the tschebyschow center routine)
		
	Returns:
		       ax: The axis object that the polyhedron has been plotted to
	"""
	m, n = A.shape
	
	try:
		# Compute vertices
		intersection_result = HalfspaceIntersection(np.hstack((A, np.array([-b]).T)), center)
		vertices = intersection_result.intersections
	except:
		raise ValueError("Error computing halfspace intersections")
	
	# Compute bounding box values for plotting
	alpha = 0.2
	box_lims = np.vstack([
		np.min(vertices, axis = 0) - alpha*(np.max(vertices, axis = 0) - np.min(vertices, axis = 0)),
		np.max(vertices, axis = 0) + alpha*(np.max(vertices, axis = 0) - np.min(vertices, axis = 0))
	])

	if n == 2:
		# Get polyhedron vertices
		x = vertices[:,0]
		y = vertices[:,1]
		
		# Get bounding box values
		xlim = box_lims[:,0]
		ylim = box_lims[:,1]
		
		# Set up canvas
		fig = plt.figure()
		ax = plt.axes()

		# Set bounding box
		ax.set_xlim(xlim)
		ax.set_ylim(ylim)
		
		# Set labels
		#ax.set_aspect('equal','box')
		ax.set_xlabel('x')
		ax.set_ylabel('y')

		# Plot halfspaces
		for normal, value in zip(A, b):
			# Check if the halfspace has vertical boundary
			if normal[1] == 0:
				# Plot vertical halfspace boundary
				ax.axvline(value/normal[0], color = 'b')
				# Fill halfspace
				ax.fill_betweenx(ylim, value/normal[0], xlim[np.where(normal[0] > 0, 1, 0)], fc = (0,0,1, 0.25))
				
			else:
				# Plot halfspace boundary
				ax.plot(xlim, (value-normal[0]*xlim)/normal[1], color = 'b')
				# Fill halfspace
				ax.fill_between(xlim, (value-normal[0]*xlim)/normal[1], ylim[np.where(normal[1] > 0, 1, 0)], fc = (0,0,1, 0.25))

		# Plot vertices
		ax.plot(x, y, 'or', markersize = 8)

	elif n == 3:
		# Get polyhedron vertices
		x = vertices[:,0]
		y = vertices[:,1]
		z = vertices[:,2]
		
		# Get bounding box values
		xlim = box_lims[:,0]
		ylim = box_lims[:,1]
		zlim = box_lims[:,2]

		# Set up canvas
		fig = plt.figure()
		ax = plt.axes(projection='3d')

		# Set bounding box
		ax.set_xlim(xlim)
		ax.set_ylim(ylim)
		ax.set_zlim(zlim)
		#ax.set_aspect('equal','box')
		
		# Set labels
		ax.set_xlabel('x')
		ax.set_ylabel('y')
		ax.set_zlabel('z')

		# Compute convex hull of vertices (the polhedron)
		hull = ConvexHull(vertices)

		# Draw the polyhedron using simplices
		for simplex in hull.simplices:
			simplex_vertices = vertices[simplex]
			# Draw the simplices of the convex hull as faces
			triangle = mplot3d.art3d.Poly3DCollection([list(map(tuple, simplex_vertices))])
			triangle.set_alpha(0.25)
			ax.add_collection3d(triangle)

		# Find which hyperplane contains which vertex (2 times ? pairs of plane,vertex ids
		vertices_in_planes = np.nonzero(np.abs(((A @ vertices.T).T - b).T) <= 1e-12)

		# Pairwise check if two vertices are on an edge
		for vertex_id in range(vertices.shape[0]):
			for other_vertex_id in range(vertex_id+1, vertices.shape[0]):
				# Get plane ids that contain first vertex
				plane_ids = set(vertices_in_planes[0][np.where(vertices_in_planes[1]==vertex_id)])
				
				# Get plane ids that contain second vertex
				other_plane_ids = set(vertices_in_planes[0][np.where(vertices_in_planes[1]==other_vertex_id)])
				
				# If at least two planes contain both vertices, they're on an outer edge
				if len(plane_ids.intersection(other_plane_ids)) >1 :
					ax.plot(vertices[[vertex_id, other_vertex_id],0], 
						 vertices[[vertex_id, other_vertex_id],1],
						 vertices[[vertex_id, other_vertex_id],2],'b')

		# Plot vertices
		ax.plot3D(x, y, z, 'or', markersize = 8)
	else:
		raise ValueError("Polyhedron plotting in %d dimensions not supported." % n)
	
	plt.title('Polyhedron')
	
	return ax

def plot_simplex_iterates(A, b, iterates, interior_point):
	""" Plot the iterations of the simplex algorithm in a 2 or 3 dimensional polyhedron
	Accepts: 
		                    A: The matrix that stores the halfspace normals row-wise
		                    b: The corresponding half space values
		             iterates: The iterates that the simplex visited
		       interior_point: Interior point of the polyhedron needed for computing half space intersections
		
	Returns:
		       No return value.
	"""
	m, n = A.shape
	
	# Plot polyhedron
	ax = plot_polyhedron(A, b, interior_point)
	
	iterates = np.vstack(iterates)
	
	number_of_iterations = len(iterates)-1
	if number_of_iterations >= 1:
		# Compute the updates
		updates = iterates[1:,:] - iterates[:-1,]
		
		# Plot the simplex moves
		if n == 2:
			ax.plot(iterates[:,0], iterates[:,1], 'r--', lineWidth = 4)
			ax.quiver(iterates[:-1,0], iterates[:-1,1], updates[:,0], updates[:,1], fc = (1,0,0,1), scale_units='xy', angles='xy', scale=1)
			plt.title('Simplex iterations in polyhedron')
			
		elif n == 3:
			ax.plot3D(iterates[:,0], iterates[:,1], iterates[:,2], 'r--', lineWidth = 4)
			#ax.quiver3D(iterates[:-1,0], iterates[:-1,1], iterates[:-1,2], updates[:,0], updates[:,1], updates[:,2], fc = (0,1,0,1), length = 0.5)
			plt.title('Simplex iterations in polyhedron')
			
		else:
			raise ValueError("Simplex iterate plotting in %d dimensions not supported." % n)

def plot_tschebyschow_center(A, b, center, radius):
	""" Plot a polyhedron defined by Ax<=b and its tschebyschow_center
	Accepts: 
		            A: The matrix that stores the halfspace normals row-wise
		            b: The corresponding half space values
		       center: A Tschebyschow center of the polyhedron
		       radius: The maximum radius corresponding to the Tschebyschow center
		
	Returns:
		       No return value.
	"""
	m, n = A.shape
	
	# Plot polyhedron
	ax = plot_polyhedron(A, b, center)
	
	if n == 2:
		ax.set_aspect('equal','box')
		# Plot Tschebyschow center and radius
		ax.add_patch(plt.Circle(center, radius, fc = (1,0,0, 0.5), ec = (0,0,0, 1), lw = 2))
		ax.plot(*center, 'or', markersize = 8)
		
	elif n == 3:
		# Parameterize sphere
		phi = np.linspace(0, 2 * np.pi, 100)
		theta = np.linspace(0, np.pi, 100)
		x = center[0] + radius * np.outer(np.cos(phi), np.sin(theta))
		y = center[1] + radius * np.outer(np.sin(phi), np.sin(theta))
		z = center[2] + radius * np.outer(np.ones(np.size(phi)), np.cos(theta))

		# Plot Tschebyschow center and radius
		ax.plot_surface(x, y, z, alpha = 0.5, ec = (1,0,0,0.2))
		ax.scatter(*center, 'or')
		
	else:
		raise ValueError("Tschebyschow center plotting in %d dimensions not supported" % n)

	plt.title('Tschebyschow center in polyhedron')
