# This module implements various plotting functions to visualize the results
# of iterative optimization schemes.

import matplotlib.pyplot as plt
plt.rcParams["figure.figsize"] = (10, 10)
import matplotlib.colors as mcolors
import numpy as np

from itertools import cycle

def plot_2d_iterates_contours(f, histories, labels):
  """ 
  Plot 2d iterates provided in histories of iterative solvers in the iterate 
  space with contour lines at the levels of the visited iterate's function values.
  
          Accepts:
                    f: the function that was minimized by the iterative solvers
            histories: list of history dictionaries created from the iterative solvers
              labels: list of label strings for the plot

          Returns:
                No return values.
  """
  
  # Determine a quadratic bounding box for the iterates
  all_iterates = np.vstack(list(np.vstack(history["iterates"]) for history in histories))
  max_abs_component = (np.abs(all_iterates).max())
  discretization_points = np.linspace(-1.5*max_abs_component, 1.5*max_abs_component, num = 251)
  X, Y = np.meshgrid(discretization_points, discretization_points)

  # Get the function values of f on the grid for contour plots
  Z = np.zeros((discretization_points.shape[0], discretization_points.shape[0])) 
  for i, x_comp in enumerate(discretization_points):
    for j, y_comp in enumerate(discretization_points):
      Z[i,j] = f(np.array([x_comp,y_comp]), derivatives=[True,False,False])["function"]
  
  for history in histories:
    # Plot contour lines at iterate function values levels (max of 20)
    contour_vals = sorted(set(history["objective_values"][20::-1]))
    plt.contour(X, Y, Z.T, levels = np.asarray(contour_vals))
    
    # Plot 2d iterates
    plt.plot(np.vstack(history["iterates"])[:,0], np.vstack(history["iterates"])[:,1], 's-')
      
  plt.gca().set_aspect('equal','box')
  plt.title('Iterates and iso-lines of function')
  plt.legend(labels)
  plt.xlabel('x')
  plt.ylabel('y')
  plt.show()


def plot_f_val_diffs(histories, reference_values, labels, condition_numbers = None):
  """
  Plot difference of objective function values provided in histories of 
  iterative solvers and user supplied reference values for each history. 
  
  If the user supplied reference values are the optimal value and the
  the problem is quadratic, then this equals the squared energy norm 
  of the error. Otherwise this method may be used to provide approximative 
  information. 
  
  Optional plot is the expected upper bound for convergence
  speed for quadratic problems provided the generalized condition number.
  
  Accepts:
            histories: list of history dictionaries created from the iterative solvers
     reference_values: list of reference values
               labels: list of label strings for the plot
    condition_numbers: list of generalized condition numbers if the problems in histories
                       were quadratic (default None) 

  Returns:
         No return values.
  """
  
  # Evaluate and plot the differences of the objective values and reference values
  for history, reference_value in zip(histories, reference_values):
    history["f_val_diffs"] = history["objective_values"] - reference_value
    plt.semilogy(history["f_val_diffs"])
  
  # If condition_numbers were supplied, assume that f was quadratic and plot
  # upper bounds on convergence speed
  bound_labels = []
  try:
    plt.gca().set_prop_cycle(None) # Restart the color cycle
    
    for history, reference_value, condition_number, label in \
      zip(histories, reference_values, condition_numbers, labels):
      # Evaluate the linear convergence factor from condition quotient  
      condition_quotient = (condition_number - 1) / (condition_number + 1)
      
      # Evaluate initial energy norm of error squared from the function value diffs
      initial_error_2 = history["objective_values"][0] - reference_value
      
      # Evaluate the predicted upper bound at each iteration starting from the initial error norm
      upper_error_2_bound = initial_error_2 * (condition_quotient ** (2*np.arange(0,len(history["objective_values"]))))
      
      plt.semilogy(upper_error_2_bound, '--')
      bound_labels.append(label + " bound")  
      
  except:
    print("No condition numbers plotable.")
    
  plt.title('Difference of functional values')
  plt.xlabel('Iteration')
  plt.ylabel('Functional value difference')
  plt.legend(labels + bound_labels)
  plt.show()


def plot_step_sizes(histories,labels):
  """Plot the step lengths of a list of histories."""
  for history in histories:
    plt.plot(history["step_lengths"])
    
  plt.title('Step lengths')
  plt.xlabel('Iteration')
  plt.ylabel('Step length')
  plt.legend(labels)
  plt.show()


def plot_grad_norms(histories,labels):
  """Plot the gradient norms of a list of histories."""
  for history in histories:
    plt.semilogy(history["gradient_norms"])
    
  plt.title('Preconditioner norm of gradients')
  plt.xlabel('Iteration')
  plt.ylabel('Norm value')
  plt.legend(labels)
  plt.show()

def plot_used_newton_direction(histories,labels):
  """Plot the boolean whether or not Newton direction was used."""
  for history in histories:
    plt.plot(history["used_newton_direction"], '*')
    
  plt.title('Used Newton direction in iteration?')
  plt.xlabel('Iteration')
  plt.ylabel('Newton used')
  plt.legend(labels)
  plt.gca().set_ylim(-0.1,1.1)
  plt.show()
